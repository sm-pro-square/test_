"""
Phase 1: Analysis
=================

Independent analysis phase where each analyst LLM analyzes the document.

This module can be run independently:
    python -m csrd_council.phases.phase1_analysis \\
        --document report.json \\
        --config council_config.json \\
        --analyst Analyst-A \\
        --output-dir ./outputs

Or run all analysts:
    python -m csrd_council.phases.phase1_analysis \\
        --document report.json \\
        --config council_config.json \\
        --output-dir ./outputs
"""

import os
import sys
import json
import argparse
from datetime import datetime
from typing import List, Dict, Optional

# Add parent to path for imports when running as script
if __name__ == "__main__":
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from csrd_council_2.config.models import CouncilConfig, ModelConfig, EndpointConfig
from csrd_council_2.config.prompts_v5 import ANALYST_SYSTEM_PROMPT, format_analyst_prompt
from csrd_council_2.models.llm_client import LLMClient
from csrd_council_2.utils.helpers import (
    load_document, chunk_by_pages, save_json, parse_llm_response,
    generate_issue_id, get_timestamp
)


def run_analyst(
    analyst: ModelConfig,
    chunks: List[Dict],
    llm_client: LLMClient,
    verbose: bool = True
) -> Dict:
    """
    Run a single analyst on all document chunks.
    
    Args:
        analyst: Analyst model configuration
        chunks: List of document chunks
        llm_client: LLM client instance
        verbose: Print progress
    
    Returns:
        Analysis result dict
    """


    
    if verbose:
        print(f"\n🔍 {analyst.name} analyzing {len(chunks)} chunk(s)...")
    
    all_issues = []
    chunk_results = []
    
    for chunk in chunks:

        if verbose:
            print(f"Processing chunk {chunk['chunk_id']}: pages {chunk['page_start']}-{chunk['page_end']}...")
        
        # Format prompt
        user_prompt = format_analyst_prompt(
            analyst_name=analyst.name,
            chunk_id=chunk['chunk_id'],
            page_start=chunk['page_start'],
            page_end=chunk['page_end'],
            content=chunk['text']
        )
        
        
        # Call LLM
        response = llm_client.generate(analyst, user_prompt, ANALYST_SYSTEM_PROMPT)

        
        
        if not response.success:
            if verbose:
                print(f"   ⚠️  Error: {response.error}")
            chunk_results.append({
                "chunk_id": chunk['chunk_id'],
                "error": response.error,
                "issues": []
            })
            continue
        
        # Parse response
        parsed = parse_llm_response(response.answer)

        
        
        if parsed.get("parse_error"):
            if verbose:
                print(f"   ⚠️  Parse error: {parsed.get('error', 'Unknown')}")
            chunk_results.append({
                "chunk_id": chunk['chunk_id'],
                "parse_error": True,
                "issues": []
            })
            continue
        
        # Extract issues and add metadata
        # issues = parsed.get("issues", [])
        # for issue in issues:
        #     issue["source_analyst"] = analyst.name
        #     issue["source_chunk"] = chunk['chunk_id']
        #     if "issue_id" not in issue or not issue["issue_id"]:
        #         issue["issue_id"] = generate_issue_id(issue, analyst.name)
        
        issues = parsed.get("issues", [])
        for issue in issues:
            issue["source_analyst"] = analyst.name
            issue["source_chunk"] = chunk['chunk_id']
            issue["issue_id"] = generate_issue_id(issue, analyst.name, chunk['chunk_id'])

        all_issues.extend(issues)
        
        chunk_results.append({
            "chunk_id": chunk['chunk_id'],
            "pages": f"{chunk['page_start']}-{chunk['page_end']}",
            "issues_found": len(issues),
            "sections_analyzed": parsed.get("sections_analyzed", ""),
            "confidence_notes": parsed.get("confidence_notes", "")
        })
        
        if verbose:
            print(f"   ✓ Found {len(issues)} issue(s)")
    
    if verbose:
        print(f"   ✅ {analyst.name} complete: {len(all_issues)} total issues")
    
    return {
        "analyst": analyst.name,
        "model_id": analyst.model_id,
        "timestamp": get_timestamp(),
        "chunks_analyzed": len(chunks),
        "total_issues": len(all_issues),
        "issues": all_issues,
        "chunk_details": chunk_results
    }


def run_phase1(
    document_path: str,
    config: CouncilConfig,
    output_dir: str,
    analyst_names: Optional[List[str]] = None,
    mock_mode: bool = False,
    verbose: bool = True
) -> List[str]:
    """
    Run Phase 1 analysis for all (or selected) analysts.
    
    Args:
        document_path: Path to document JSON
        config: Council configuration
        output_dir: Output directory for results
        analyst_names: Optional list of specific analysts to run (None = all)
        mock_mode: Use mock LLM
        verbose: Print progress
    
    Returns:
        List of output file paths
    """
    if verbose:
        print("\n" + "="*70)
        print("PHASE 1: INDEPENDENT ANALYSIS")
        print("="*70)
    
    # Load document
    if verbose:
        print(f"\n📂 Loading document: {document_path}")
    pages = load_document(document_path)
    
    # Chunk document
    chunks = chunk_by_pages(
        pages, 
        config.pages_per_chunk, 
        config.chunk_overlap_pages
    )
    if verbose:
        print(f"📦 Created {len(chunks)} chunk(s) from {len(pages)} pages")
    
    # Filter analysts if specified
    analysts = config.analysts
    if analyst_names:
        analysts = [a for a in analysts if a.name in analyst_names]
        if verbose:
            print(f"👤 Running {len(analysts)} selected analyst(s): {[a.name for a in analysts]}")
    else:
        if verbose:
            print(f"👥 Running {len(analysts)} analyst(s): {[a.name for a in analysts]}")
    
    # Initialize LLM client
    llm_client = LLMClient(mock_mode=mock_mode)
    
    # Create output directory
    os.makedirs(output_dir, exist_ok=True)
    
    # Run each analyst
    output_files = []
    for analyst in analysts:
        result = run_analyst(analyst, chunks, llm_client, verbose)
        
        # Add document metadata
        result["document"] = {
            "path": document_path,
            "total_pages": len(pages),
            "chunks": len(chunks)
        }
        
        # Save result
        output_path = os.path.join(output_dir, f"phase1_{analyst.name}.json")
        save_json(result, output_path)
        output_files.append(output_path)
        
        if verbose:
            print(f"   💾 Saved: {output_path}")
    
    if verbose:
        print(f"\n✅ Phase 1 complete: {len(output_files)} analysis file(s) generated")
    
    return output_files


def main():
    parser = argparse.ArgumentParser(
        description="CSRD Council - Phase 1: Analysis",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    parser.add_argument("--document", "-d", required=True,
                       help="Path to document JSON file")
    parser.add_argument("--config", "-c", required=True,
                       help="Path to council config JSON/YAML file")
    parser.add_argument("--output-dir", "-o", default="./outputs",
                       help="Output directory (default: ./outputs)")
    parser.add_argument("--analyst", "-a", action="append",
                       help="Specific analyst to run (can be repeated). If not specified, runs all.")
    parser.add_argument("--mock", action="store_true",
                       help="Use mock LLM for testing")
    parser.add_argument("--quiet", "-q", action="store_true",
                       help="Suppress progress output")
    
    args = parser.parse_args()
    
    # Load config
    if args.config.endswith('.yaml') or args.config.endswith('.yml'):
        config = CouncilConfig.from_yaml(args.config)
    else:
        config = CouncilConfig.from_json(args.config)
    
    # Validate config
    issues = config.validate()
    for issue in issues:
        print(issue)
    
    # Run phase 1
    output_files = run_phase1(
        document_path=args.document,
        config=config,
        output_dir=args.output_dir,
        analyst_names=args.analyst,
        mock_mode=args.mock,
        verbose=not args.quiet
    )
    
    print(f"\nOutput files: {output_files}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
