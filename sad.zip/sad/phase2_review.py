"""
Phase 2: Peer Review (v2.0)
===========================

Peer review phase where reviewer LLMs evaluate issues found in Phase 1.
Updated to support new confidence levels and cross-section risk assessment.

This module can be run independently:
    python -m csrd_council.phases.phase2_review \\
        --phase1-dir ./outputs \\
        --document report.json \\
        --config council_config.json \\
        --output-dir ./outputs

Or run a single reviewer:
    python -m csrd_council.phases.phase2_review \\
        --phase1-dir ./outputs \\
        --document report.json \\
        --config council_config.json \\
        --reviewer Reviewer-1 \\
        --output-dir ./outputs
"""

import os
import sys
import json
import argparse
from datetime import datetime
from typing import List, Dict, Optional

# Add parent to path for imports when running as script
if __name__ == "__main__":
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from csrd_council_2.config.models import CouncilConfig, ModelConfig
from csrd_council_2.config.prompts_v5 import REVIEWER_SYSTEM_PROMPT, format_reviewer_prompt
from csrd_council_2.models.llm_client import LLMClient
from csrd_council_2.utils.helpers import (
    load_document, load_json, save_json, parse_llm_response,
    find_phase1_files, extract_context_for_issue, get_timestamp
)


# =============================================================================
# CONFIGURATION v2.0
# =============================================================================

# Types d'issues avec risque élevé de faux positifs (requiert validation renforcée)
HIGH_FP_RISK_TYPES = [
    "MISSING_INFORMATION",
    "AMBIGUOUS_STATEMENT",
]

# Types d'issues à haute priorité (risque réglementaire)
HIGH_PRIORITY_TYPES = [
    "GREENWASHING",
    "REGULATORY_GAP",
    "NUMERIC_INCONSISTENCY",
    "LOGICAL_CONTRADICTION",
]


def collect_issues_from_phase1(phase1_files: List[str]) -> List[Dict]:
    """
    Collect all issues from Phase 1 analysis files.
    
    Returns:
        List of issues with source metadata
    """
    all_issues = []
    
    for filepath in phase1_files:
        data = load_json(filepath)
        analyst_name = data.get("analyst", "Unknown")
        
        for issue in data.get("issues", []):
            # Ensure issue has required fields
            issue_copy = issue.copy()
            issue_copy["_source_file"] = filepath
            issue_copy["_source_analyst"] = analyst_name
            all_issues.append(issue_copy)
    
    return all_issues


def get_issue_field_with_default(issue: Dict, field: str, default: str = "N/A") -> str:
    """
    Get a field from issue dict with a default value.
    Handles both old and new issue formats for backwards compatibility.
    """
    value = issue.get(field)
    if value is None or value == "":
        return default
    return str(value)


def run_reviewer(
    reviewer: ModelConfig,
    issues: List[Dict],
    pages: List[Dict],
    llm_client: LLMClient,
    verbose: bool = True
) -> Dict:
    """
    Run a single reviewer on all issues.
    
    Args:
        reviewer: Reviewer model configuration
        issues: List of issues to review
        pages: Document pages (for context extraction)
        llm_client: LLM client instance
        verbose: Print progress
    
    Returns:
        Review results dict
    """
    if verbose:
        print(f"\n🔍 {reviewer.name} reviewing {len(issues)} issue(s)...")
    
    reviews = []
    
    for i, issue in enumerate(issues):
        issue_id = issue.get("issue_id", f"issue-{i}")
        issue_type = issue.get("type", "UNKNOWN")
        title = issue.get("title", "Untitled")[:50]
        
        if verbose:
            # Mark high FP risk types
            risk_marker = "⚠️ " if issue_type in HIGH_FP_RISK_TYPES else ""
            priority_marker = "🔴 " if issue_type in HIGH_PRIORITY_TYPES else ""
            print(f"   Reviewing {i+1}/{len(issues)}: {priority_marker}{risk_marker}{title}...")
        
        # Extract context for this issue
        context = extract_context_for_issue(issue, pages)
        
        # Format evidence
        evidence = issue.get("evidence", [])
        evidence_text = "\n".join([f"- {e}" for e in evidence]) if evidence else "No evidence provided"
        
        # Get new fields with backwards compatibility (default values for old format)
        confidence = get_issue_field_with_default(issue, "confidence", "MEDIUM")
        cross_section_note = get_issue_field_with_default(
            issue, 
            "cross_section_note", 
            "Non spécifié (format legacy)" if issue.get("cross_section_check_needed") else "N/A"
        )
        
        # Format prompt (blind review - no source analyst info)
        user_prompt = format_reviewer_prompt(
            reviewer_name=reviewer.name,
            issue_id=issue_id,
            issue_type=issue_type,
            severity=issue.get("severity", "UNKNOWN"),
            confidence=confidence,
            title=issue.get("title", "Untitled"),
            description=issue.get("description", "No description"),
            evidence=evidence_text,
            context=context,
            cross_section_note=cross_section_note
        )
        
        # Call LLM
        response = llm_client.generate(reviewer, user_prompt, REVIEWER_SYSTEM_PROMPT)
        
        if not response.success:
            if verbose:
                print(f"   ⚠️  Error: {response.error}")
            reviews.append({
                "issue_id": issue_id,
                "reviewer_id": reviewer.name,
                "error": response.error,
                "evaluation": None
            })
            continue
        
        # Parse response
        parsed = parse_llm_response(response.answer)
        
        if parsed.get("parse_error"):
            if verbose:
                print(f"   ⚠️  Parse error")
            reviews.append({
                "issue_id": issue_id,
                "reviewer_id": reviewer.name,
                "parse_error": True,
                "evaluation": None
            })
            continue
        
        # Extract evaluation
        evaluation = parsed.get("evaluation", parsed)
        
        # Apply cross-section risk penalty for high FP risk types
        if issue_type in HIGH_FP_RISK_TYPES:
            cross_section_risk = evaluation.get("cross_section_risk", "MEDIUM")
            validity_score = evaluation.get("validity_score", 0.5)
            
            # Apply penalty based on cross-section risk
            if cross_section_risk == "HIGH":
                adjusted_score = max(0.0, validity_score - 0.15)
                evaluation["validity_score_original"] = validity_score
                evaluation["validity_score"] = adjusted_score
                evaluation["validity_adjustment_reason"] = "Cross-section risk HIGH penalty (-0.15)"
            elif cross_section_risk == "MEDIUM":
                adjusted_score = max(0.0, validity_score - 0.08)
                evaluation["validity_score_original"] = validity_score
                evaluation["validity_score"] = adjusted_score
                evaluation["validity_adjustment_reason"] = "Cross-section risk MEDIUM penalty (-0.08)"
        
        review_result = {
            "issue_id": issue_id,
            "issue_type": issue_type,
            "issue_title": issue.get("title", ""),
            "issue_source_analyst": issue.get("_source_analyst", "Unknown"),
            "issue_confidence": confidence,
            "reviewer_id": reviewer.name,
            "evaluation": evaluation,
            "high_fp_risk": issue_type in HIGH_FP_RISK_TYPES,
            "high_priority": issue_type in HIGH_PRIORITY_TYPES
        }
        
        reviews.append(review_result)
        
        # Log result
        validity = evaluation.get("validity_score", "?")
        assessment = evaluation.get("overall_assessment", "?")
        cross_risk = evaluation.get("cross_section_risk", "?")
        
        if verbose:
            validity_str = f"{validity:.2f}" if isinstance(validity, float) else str(validity)
            adjustment_note = ""
            if evaluation.get("validity_adjustment_reason"):
                adjustment_note = f" (adjusted: {evaluation.get('validity_adjustment_reason')})"
            print(f"   ✓ Validity: {validity_str}{adjustment_note}, Cross-risk: {cross_risk}, Assessment: {assessment}")
    
    if verbose:
        # Summary stats
        valid_reviews = [r for r in reviews if r.get("evaluation")]
        high_validity = len([r for r in valid_reviews 
                           if r.get("evaluation", {}).get("validity_score", 0) >= 0.7])
        low_validity = len([r for r in valid_reviews 
                          if r.get("evaluation", {}).get("validity_score", 0) < 0.5])
        
        print(f"   ✅ {reviewer.name} complete: {len(reviews)} review(s)")
        print(f"      High validity (≥0.7): {high_validity}, Low validity (<0.5): {low_validity}")
    
    return {
        "reviewer": reviewer.name,
        "model_id": reviewer.model_id,
        "timestamp": get_timestamp(),
        "issues_reviewed": len(issues),
        "reviews": reviews,
        "stats": {
            "total": len(reviews),
            "high_fp_risk_types": len([r for r in reviews if r.get("high_fp_risk")]),
            "high_priority_types": len([r for r in reviews if r.get("high_priority")])
        }
    }


def run_phase2(
    phase1_dir: str,
    document_path: str,
    config: CouncilConfig,
    output_dir: str,
    reviewer_names: Optional[List[str]] = None,
    mock_mode: bool = False,
    verbose: bool = True
) -> List[str]:
    """
    Run Phase 2 peer review for all (or selected) reviewers.
    
    Args:
        phase1_dir: Directory containing Phase 1 outputs
        document_path: Path to original document JSON
        config: Council configuration
        output_dir: Output directory for results
        reviewer_names: Optional list of specific reviewers to run
        mock_mode: Use mock LLM
        verbose: Print progress
    
    Returns:
        List of output file paths
    """
    if verbose:
        print("\n" + "="*70)
        print("PHASE 2: PEER REVIEW (v2.0 - Enhanced FP Detection)")
        print("="*70)
    
    # Find Phase 1 files
    phase1_files = find_phase1_files(phase1_dir)
    if not phase1_files:
        print(f"❌ No Phase 1 files found in {phase1_dir}")
        return []
    
    if verbose:
        print(f"\n📂 Found ==> {len(phase1_files)} Phase-1 file(s)")
    
    # Collect all issues
    all_issues = collect_issues_from_phase1(phase1_files)
    if verbose:
        print(f"📋 Collected {len(all_issues)} issue(s) to review")
        
        # Show breakdown by type
        type_counts = {}
        for issue in all_issues:
            t = issue.get("type", "UNKNOWN")
            type_counts[t] = type_counts.get(t, 0) + 1
        
        print(f"   Breakdown by type:")
        for t, count in sorted(type_counts.items(), key=lambda x: -x[1]):
            risk_marker = "⚠️ HIGH_FP_RISK" if t in HIGH_FP_RISK_TYPES else ""
            priority_marker = "🔴 HIGH_PRIORITY" if t in HIGH_PRIORITY_TYPES else ""
            markers = f" {priority_marker}{risk_marker}".strip()
            print(f"      - {t}: {count}{markers}")
    
    if not all_issues:
        print("⚠️  No issues to review")
        return []
    
    # Load document for context
    if verbose:
        print(f"📄 Loading document: {document_path}")
    pages = load_document(document_path)
    
    # Filter reviewers if specified
    reviewers = config.reviewers
    if reviewer_names:
        reviewers = [r for r in reviewers if r.name in reviewer_names]
    
    if verbose:
        print(f"👥 Running {len(reviewers)} reviewer(s): {[r.name for r in reviewers]}")
    
    # Initialize LLM client
    llm_client = LLMClient(mock_mode=mock_mode)
    
    # Create output directory
    os.makedirs(output_dir, exist_ok=True)
    
    # Run each reviewer
    output_files = []
    all_reviews = []
    
    for reviewer in reviewers:
        result = run_reviewer(reviewer, all_issues, pages, llm_client, verbose)
        all_reviews.extend(result["reviews"])
        
        # Save individual reviewer result
        output_path = os.path.join(output_dir, f"phase2_{reviewer.name}.json")
        save_json(result, output_path)
        output_files.append(output_path)
        
        if verbose:
            print(f"   💾 Saved: {output_path}")
    
    # Compute aggregate stats
    valid_reviews = [r for r in all_reviews if r.get("evaluation")]
    
    aggregate_stats = {
        "total_reviews": len(all_reviews),
        "valid_reviews": len(valid_reviews),
        "high_validity_count": len([r for r in valid_reviews 
                                   if r.get("evaluation", {}).get("validity_score", 0) >= 0.7]),
        "medium_validity_count": len([r for r in valid_reviews 
                                     if 0.5 <= r.get("evaluation", {}).get("validity_score", 0) < 0.7]),
        "low_validity_count": len([r for r in valid_reviews 
                                  if r.get("evaluation", {}).get("validity_score", 0) < 0.5]),
        "high_fp_risk_issues": len([r for r in valid_reviews if r.get("high_fp_risk")]),
        "high_priority_issues": len([r for r in valid_reviews if r.get("high_priority")]),
        "cross_section_high_risk": len([r for r in valid_reviews 
                                       if r.get("evaluation", {}).get("cross_section_risk") == "HIGH"]),
        "adjusted_scores_count": len([r for r in valid_reviews 
                                     if r.get("evaluation", {}).get("validity_adjustment_reason")])
    }
    
    # Save combined reviews file
    combined_result = {
        "timestamp": get_timestamp(),
        "version": "2.0",
        "phase1_sources": phase1_files,
        "total_issues": len(all_issues),
        "total_reviewers": len(reviewers),
        "aggregate_stats": aggregate_stats,
        "reviews": all_reviews
    }
    
    combined_path = os.path.join(output_dir, "phase2_all_reviews.json")
    save_json(combined_result, combined_path)
    output_files.append(combined_path)
    
    if verbose:
        print(f"\n" + "="*50)
        print(f"📊 PHASE 2 AGGREGATE STATS:")
        print(f"   Total reviews: {aggregate_stats['total_reviews']}")
        print(f"   High validity (≥0.7): {aggregate_stats['high_validity_count']}")
        print(f"   Medium validity (0.5-0.7): {aggregate_stats['medium_validity_count']}")
        print(f"   Low validity (<0.5): {aggregate_stats['low_validity_count']}")
        print(f"   High FP risk issues: {aggregate_stats['high_fp_risk_issues']}")
        print(f"   Cross-section HIGH risk: {aggregate_stats['cross_section_high_risk']}")
        print(f"   Scores adjusted: {aggregate_stats['adjusted_scores_count']}")
        print(f"="*50)
        print(f"\n✅ Phase 2 complete: {len(output_files)} review file(s) generated")
    
    return output_files


def main():
    parser = argparse.ArgumentParser(
        description="CSRD Council - Phase 2: Peer Review (v2.0)",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    parser.add_argument("--phase1-dir", required=True,
                       help="Directory containing Phase 1 output files")
    parser.add_argument("--document", "-d", required=True,
                       help="Path to original document JSON file")
    parser.add_argument("--config", "-c", required=True,
                       help="Path to council config JSON/YAML file")
    parser.add_argument("--output-dir", "-o", default="./outputs",
                       help="Output directory (default: ./outputs)")
    parser.add_argument("--reviewer", "-r", action="append",
                       help="Specific reviewer to run (can be repeated)")
    parser.add_argument("--mock", action="store_true",
                       help="Use mock LLM for testing")
    parser.add_argument("--quiet", "-q", action="store_true",
                       help="Suppress progress output")
    
    args = parser.parse_args()
    
    # Load config
    if args.config.endswith('.yaml') or args.config.endswith('.yml'):
        config = CouncilConfig.from_yaml(args.config)
    else:
        config = CouncilConfig.from_json(args.config)
    
    # Run phase 2
    output_files = run_phase2(
        phase1_dir=args.phase1_dir,
        document_path=args.document,
        config=config,
        output_dir=args.output_dir,
        reviewer_names=args.reviewer,
        mock_mode=args.mock,
        verbose=not args.quiet
    )
    
    print(f"\nOutput files: {output_files}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
