#!/usr/bin/env python3
"""
CSRD Council - Main Runner v2.0
===============================

Run the complete CSRD Council analysis pipeline or individual phases.

Updated for v2.0:
- Passes document_path to Phase 3 (required for chunk-by-chunk processing)
- Support for new validity thresholds
- Better error handling and reporting

Usage:
    # Run all phases
    python run_council.py --document report.json --config config.json --output-dir ./results
    
    # Run individual phases
    python run_council.py --phase 1 --document report.json --config config.json --output-dir ./results
    python run_council.py --phase 2 --document report.json --config config.json --output-dir ./results
    python run_council.py --phase 3 --document report.json --config config.json --output-dir ./results
"""

import os
import sys
import argparse
import time
from datetime import datetime

# Add package to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from csrd_council_2.config.models import CouncilConfig
from csrd_council_2.phases.phase1_analysis import run_phase1
from csrd_council_2.phases.phase2_review import run_phase2
from csrd_council_2.phases.phase3_judgment import run_phase3
from csrd_council_2.utils.helpers import load_document, save_json, get_timestamp


def run_full_pipeline(
    document_path: str,
    config: CouncilConfig,
    output_dir: str,
    mock_mode: bool = False,
    verbose: bool = True
) -> dict:
    """
    Run the complete CSRD Council pipeline.
    
    Phase 1: Independent analysis by each analyst
    Phase 2: Peer review of all issues
    Phase 3: Judge aggregation and final report
    
    Returns:
        Dict with all output file paths
    """
    start_time = time.time()
    
    print("\n" + "="*70)
    print("🏛️  CSRD LLM COUNCIL - FULL PIPELINE v2.0")
    print("="*70)
    print(f"📄 Document: {document_path}")
    print(f"📁 Output: {output_dir}")
    print(f"🎭 Mock mode: {mock_mode}")
    
    # Validate config
    issues = config.validate()
    if issues:
        print("\n⚠️  Configuration warnings:")
        for issue in issues:
            print(f"   {issue}")
    
    # Validate document exists
    if not os.path.exists(document_path):
        print(f"\n❌ Document not found: {document_path}")
        return {"phase1": [], "phase2": [], "phase3": {}}
    
    # Get document page count for metadata
    pages = load_document(document_path)
    num_pages = len(pages)
    print(f"📑 Pages: {num_pages}")
    
    outputs = {
        "phase1": [],
        "phase2": [],
        "phase3": {}
    }
    
    # Phase 1: Analysis
    print("\n" + "-"*70)
    outputs["phase1"] = run_phase1(
        document_path=document_path,
        config=config,
        output_dir=output_dir,
        mock_mode=mock_mode,
        verbose=verbose
    )
    
    if not outputs["phase1"]:
        print("❌ Phase 1 failed, stopping pipeline")
        return outputs
    
    # Phase 2: Review
    print("\n" + "-"*70)
    outputs["phase2"] = run_phase2(
        phase1_dir=output_dir,
        document_path=document_path,
        config=config,
        output_dir=output_dir,
        mock_mode=mock_mode,
        verbose=verbose
    )
    
    if not outputs["phase2"]:
        print("❌ Phase 2 failed, stopping pipeline")
        return outputs
    
    # Phase 3: Judgment
    # FIX: Pass document_path to Phase 3 (required for chunk-by-chunk processing)
    print("\n" + "-"*70)
    outputs["phase3"] = run_phase3(
        phase1_dir=output_dir,
        phase2_dir=output_dir,
        config=config,
        output_dir=output_dir,
        document_path=document_path,  # ← FIX: Added document_path
        num_pages=num_pages,
        mock_mode=mock_mode,
        verbose=verbose
    )
    
    elapsed = time.time() - start_time
    
    # Save run metadata
    run_metadata = {
        "timestamp": get_timestamp(),
        "version": "2.0",
        "document": document_path,
        "num_pages": num_pages,
        "config": config.to_dict(),
        "outputs": outputs,
        "elapsed_time_seconds": elapsed,
        "mock_mode": mock_mode
    }
    
    metadata_path = os.path.join(output_dir, "run_metadata.json")
    save_json(run_metadata, metadata_path)
    
    print("\n" + "="*70)
    print("✅ PIPELINE COMPLETE")
    print("="*70)
    print(f"⏱️  Total time: {elapsed:.1f}s")
    print(f"\n📁 Output files:")
    print(f"   Phase 1: {len(outputs['phase1'])} file(s)")
    print(f"   Phase 2: {len(outputs['phase2'])} file(s)")
    print(f"   Phase 3: JSON + HTML")
    
    html_path = outputs['phase3'].get('html', 'N/A')
    print(f"\n🌐 HTML Report: {html_path}")
    
    if html_path != 'N/A':
        print(f"\n💡 Open the HTML report in your browser to view results")
    
    return outputs


def main():
    parser = argparse.ArgumentParser(
        description="CSRD Council - Multi-LLM Analysis Pipeline v2.0",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    # Run full pipeline
    python run_council.py -d report.json -c config.json -o ./results
    
    # Run with mock LLM
    python run_council.py -d report.json -c config.json -o ./results --mock
    
    # Run only Phase 1
    python run_council.py --phase 1 -d report.json -c config.json -o ./results
    
    # Run only Phase 2 (requires Phase 1 outputs)
    python run_council.py --phase 2 -d report.json -c config.json -o ./results
    
    # Run only Phase 3 (requires Phase 1 & 2 outputs AND document)
    python run_council.py --phase 3 -d report.json -c config.json -o ./results
        """
    )
    
    parser.add_argument("--document", "-d",
                       help="Path to document JSON file (required for all phases)")
    parser.add_argument("--config", "-c", required=True,
                       help="Path to council config JSON file")
    parser.add_argument("--output-dir", "-o", default="./outputs",
                       help="Output directory (default: ./outputs)")
    parser.add_argument("--phase", type=int, choices=[1, 2, 3],
                       help="Run only specific phase (default: run all)")
    parser.add_argument("--mock", action="store_true",
                       help="Use mock LLM for testing")
    parser.add_argument("--quiet", "-q", action="store_true",
                       help="Suppress progress output")
    
    args = parser.parse_args()
    
    # Load config
    config = CouncilConfig.from_json(args.config)
    
    # Create output directory
    os.makedirs(args.output_dir, exist_ok=True)
    
    if args.phase is None:
        # Run full pipeline
        if not args.document:
            parser.error("--document is required for full pipeline")
        
        run_full_pipeline(
            document_path=args.document,
            config=config,
            output_dir=args.output_dir,
            mock_mode=args.mock,
            verbose=not args.quiet
        )
    
    elif args.phase == 1:
        if not args.document:
            parser.error("--document is required for Phase 1")
        
        run_phase1(
            document_path=args.document,
            config=config,
            output_dir=args.output_dir,
            mock_mode=args.mock,
            verbose=not args.quiet
        )
    
    elif args.phase == 2:
        if not args.document:
            parser.error("--document is required for Phase 2")
        
        run_phase2(
            phase1_dir=args.output_dir,
            document_path=args.document,
            config=config,
            output_dir=args.output_dir,
            mock_mode=args.mock,
            verbose=not args.quiet
        )
    
    elif args.phase == 3:
        # FIX: Document is now required for Phase 3
        if not args.document:
            parser.error("--document is required for Phase 3 (chunk-by-chunk processing)")
        
        if not os.path.exists(args.document):
            print(f"❌ Document not found: {args.document}")
            return 1
        
        pages = load_document(args.document)
        
        run_phase3(
            phase1_dir=args.output_dir,
            phase2_dir=args.output_dir,
            config=config,
            output_dir=args.output_dir,
            document_path=args.document,  # ← FIX: Added document_path
            num_pages=len(pages),
            mock_mode=args.mock,
            verbose=not args.quiet
        )
    
    return 0


if __name__ == "__main__":
    sys.exit(main())