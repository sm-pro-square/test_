#!/usr/bin/env python3
"""
HTML Report Generator - Standalone Script
==========================================

Generate HTML report from Phase 3 judgment JSON file.

Usage:
    python generate_html_report.py --json phase3_judgment.json --output report.html
    
    # With document for page viewer (recommended)
    python generate_html_report.py --json phase3_judgment.json --document report.json --output report.html
    
    # Specify custom title
    python generate_html_report.py --json phase3_judgment.json --title "My CSRD Audit" --output report.html

Requirements:
    - phase3_judgment.json (required): Output from Phase 3
    - report.json (optional): Original document for source page viewer
"""

import os
import sys
import json
import argparse
from datetime import datetime
from typing import Dict, List, Optional

# Try to import from package, otherwise use local
try:
    from csrd_council_2.utils.html_generator import generate_html_report
    from csrd_council_2.utils.helpers import load_document, load_json
except ImportError:
    # Standalone mode - include minimal required functions
    pass


def load_json_file(filepath: str) -> Dict:
    """Load JSON file."""
    with open(filepath, 'r', encoding='utf-8') as f:
        return json.load(f)


def load_document_pages(document_path: str) -> Dict[int, str]:
    """Load document and return dict mapping page_number -> content."""
    if not document_path or not os.path.exists(document_path):
        return {}
    
    try:
        with open(document_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        # Handle different document formats
        pages = data if isinstance(data, list) else data.get("pages", [])
        
        return {p.get('page_number', i+1): p.get('content', '') for i, p in enumerate(pages)}
    except Exception as e:
        print(f"⚠️  Warning: Could not load document: {e}")
        return {}


def extract_metadata_from_judgment(judgment: Dict) -> Dict:
    """Extract metadata from judgment JSON."""
    meta = judgment.get("_metadata", {})
    summary = judgment.get("executive_summary", {})
    
    return {
        "total_pages": meta.get("num_pages", "N/A"),
        "num_analysts": len(set(
            c.get("analyst", "") 
            for issue in judgment.get("confirmed_issues", [])
            for c in issue.get("analyst_contributions", [])
        )) or meta.get("num_analysts", "N/A"),
        "num_reviewers": meta.get("num_reviewers", "N/A"),
        "num_chunks": meta.get("num_chunks", "N/A"),
        "generated_at": meta.get("timestamp", datetime.now().isoformat()),
        "version": meta.get("version", "1.0")
    }


def extract_phase1_analyses(judgment: Dict) -> List[Dict]:
    """Extract analyst information from judgment."""
    analysts = {}
    
    for issue in judgment.get("confirmed_issues", []):
        for contrib in issue.get("analyst_contributions", []):
            analyst = contrib.get("analyst", "Unknown")
            if analyst not in analysts:
                analysts[analyst] = {"analyst": analyst, "total_issues": 0}
            analysts[analyst]["total_issues"] += 1
    
    return list(analysts.values())


# =============================================================================
# EMBEDDED HTML GENERATOR (for standalone mode)
# =============================================================================

def markdown_to_html_simple(text: str) -> str:
    """Simple markdown to HTML conversion."""
    import re
    if not text:
        return ""
    
    # Basic conversions
    text = re.sub(r'\*\*([^*]+)\*\*', r'<strong>\1</strong>', text)
    text = re.sub(r'\*([^*]+)\*', r'<em>\1</em>', text)
    text = re.sub(r'`([^`]+)`', r'<code>\1</code>', text)
    
    # Paragraphs
    paragraphs = text.split('\n\n')
    html_parts = [f'<p>{p.strip()}</p>' for p in paragraphs if p.strip()]
    
    return '\n'.join(html_parts)


def generate_html_report_standalone(
    judgment: Dict,
    metadata: Dict = None,
    phase1_analyses: List[Dict] = None,
    document_pages: Dict[int, str] = None,
    title: str = "CSRD Council Report"
) -> str:
    """
    Generate HTML report from judgment data (standalone version).
    """
    import html as html_module
    import re
    
    metadata = metadata or {}
    phase1_analyses = phase1_analyses or []
    document_pages = document_pages or {}
    
    summary = judgment.get("executive_summary", {})
    confirmed_issues = judgment.get("confirmed_issues", [])
    dismissed_issues = judgment.get("dismissed_issues", [])
    needs_verification = judgment.get("needs_verification", [])
    
    severity_colors = {"CRITICAL": "#dc2626", "HIGH": "#ea580c", "MEDIUM": "#ca8a04", "LOW": "#16a34a"}
    
    # v2.0 fields
    by_type = summary.get("by_type", {})
    greenwashing_count = summary.get("greenwashing_count", 0)
    greenwashing_risk = summary.get("greenwashing_risk_level", "LOW")
    total_needs_verification = summary.get("total_needs_verification", len(needs_verification))
    
    # Greenwashing alert
    greenwashing_alert = ""
    if greenwashing_count > 0:
        gw_colors = {"CRITICAL": "#dc2626", "HIGH": "#ea580c", "MEDIUM": "#ca8a04", "LOW": "#22c55e"}
        gw_col = gw_colors.get(greenwashing_risk, "#ca8a04")
        greenwashing_alert = f'''
        <div style="display:flex;gap:1rem;align-items:center;background:linear-gradient(135deg,#fef2f2,#fff);border:2px solid {gw_col};border-radius:.75rem;padding:1.5rem;margin-bottom:2rem">
            <div style="font-size:2.5rem">🚨</div>
            <div>
                <div style="font-weight:700;color:{gw_col};font-size:1.1rem">GREENWASHING DÉTECTÉ 
                    <span style="background:{gw_col};color:#fff;padding:.2rem .6rem;border-radius:1rem;font-size:.7rem;margin-left:.5rem">{greenwashing_risk}</span>
                </div>
                <div style="color:#374151;margin-top:.25rem">{greenwashing_count} issue(s) de greenwashing identifiée(s). Risque réglementaire à évaluer.</div>
            </div>
        </div>'''
    
    # Type breakdown
    type_breakdown = ""
    if by_type:
        type_colors = {
            "GREENWASHING": "#dc2626", "NUMERIC_INCONSISTENCY": "#ea580c", "REGULATORY_GAP": "#dc2626",
            "LOGICAL_CONTRADICTION": "#ea580c", "MISSING_INFORMATION": "#ca8a04", "AMBIGUOUS_STATEMENT": "#eab308",
            "CONCEPTUAL_INCONSISTENCY": "#f59e0b", "CROSS_REFERENCE_ERROR": "#22c55e"
        }
        total = sum(by_type.values()) or 1
        bars = ""
        for t, c in sorted(by_type.items(), key=lambda x: -x[1]):
            pct = (c / total) * 100
            col = type_colors.get(t, "#6b7280")
            icon = "🚨 " if t == "GREENWASHING" else ""
            bars += f'''<div style="display:flex;align-items:center;gap:.75rem;margin-bottom:.5rem">
                <span style="width:200px;font-size:.85rem;color:#374151">{icon}{t.replace("_", " ").title()}</span>
                <span style="width:30px;text-align:right;font-weight:600;font-size:.85rem">{c}</span>
                <div style="flex:1;height:8px;background:#e5e7eb;border-radius:4px;overflow:hidden">
                    <div style="height:100%;width:{pct}%;background:{col};border-radius:4px"></div>
                </div>
            </div>'''
        type_breakdown = f'<div style="background:#f9fafb;padding:1.25rem;border-radius:.75rem;margin-bottom:1.5rem"><h4 style="margin-bottom:1rem;color:#374151">📊 Répartition par Type</h4>{bars}</div>'
    
    # Needs verification section
    verification_section = ""
    if needs_verification:
        items = ""
        for v in needs_verification:
            vid = v.get("issue_id", "N/A")
            vtitle = html_module.escape(v.get("title", ""))
            vtype = v.get("type", "N/A")
            vreason = html_module.escape(v.get("verification_reason", v.get("_filter_reason", "À vérifier")))
            vcheck = html_module.escape(v.get("what_to_check", "Vérifier dans les autres sections"))
            vvalid = v.get("validity_score", 0)
            vrisk = v.get("cross_section_risk", "UNKNOWN")
            risk_col = {"HIGH": "#dc2626", "MEDIUM": "#ca8a04", "LOW": "#22c55e"}.get(vrisk, "#6b7280")
            items += f'''<div style="border:1px solid #e5e7eb;border-radius:.5rem;padding:1rem;margin-bottom:.75rem;background:#f9fafb">
                <div style="display:flex;flex-wrap:wrap;gap:.5rem;align-items:center;margin-bottom:.5rem">
                    <span style="font-family:monospace;background:#e5e7eb;padding:.15rem .4rem;border-radius:.25rem;font-size:.8rem">{vid}</span>
                    <span style="color:#4b5563;font-size:.8rem">{vtype}</span>
                    <span style="font-size:.8rem;color:#4b5563">Validity: {vvalid:.0%}</span>
                    <span style="background:{risk_col};color:#fff;padding:.1rem .4rem;border-radius:.25rem;font-size:.7rem">Cross: {vrisk}</span>
                </div>
                <div style="font-weight:600;margin-bottom:.5rem">{vtitle}</div>
                <div style="font-size:.85rem;color:#4b5563"><strong>Raison:</strong> {vreason}</div>
                <div style="font-size:.85rem;color:#4b5563;margin-top:.25rem"><strong>À vérifier:</strong> {vcheck}</div>
            </div>'''
        verification_section = f'''<div style="background:#fff;border-radius:.75rem;padding:2rem;margin-bottom:2rem;box-shadow:0 1px 3px rgba(0,0,0,.1);border-left:4px solid #8b5cf6">
            <h2 style="border-bottom:2px solid #e5e7eb;padding-bottom:.75rem;margin-bottom:1rem">🔍 À Vérifier ({len(needs_verification)})</h2>
            <p style="color:#4b5563;margin-bottom:1rem;font-size:.9rem">Issues avec validité moyenne ou risque de faux positif. Vérification manuelle requise.</p>
            {items}
        </div>'''
    
    # Confirmed issues
    issues_html = ""
    for issue in confirmed_issues:
        severity = issue.get("final_severity", issue.get("severity", "MEDIUM"))
        issue_type = issue.get("type", "N/A")
        color = severity_colors.get(severity, "#6b7280")
        consensus = issue.get("consensus", {})
        review_scores = consensus.get("review_scores", {})
        validity_score = review_scores.get("validity", 0)
        evidence_score = review_scores.get("evidence", 0)
        confidence = consensus.get("confidence", "N/A")
        
        is_greenwashing = issue_type == "GREENWASHING"
        card_style = "border:2px solid #dc2626;background:linear-gradient(135deg,#fef2f2,#fff)" if is_greenwashing else "border:1px solid #e5e7eb"
        gw_badge = '<span style="background:#dc2626;color:#fff;padding:.2rem .6rem;border-radius:1rem;font-size:.7rem;font-weight:600">🚨 GREENWASHING</span>' if is_greenwashing else ""
        
        analyst_contributions = issue.get("analyst_contributions", [])
        num_analysts = len(analyst_contributions)
        analysts_badge = f'<span style="background:#2563eb;color:#fff;padding:.2rem .6rem;border-radius:1rem;font-size:.7rem;font-weight:600">{num_analysts} analyste{"s" if num_analysts > 1 else ""}</span>' if num_analysts > 0 else ""
        
        # Extract review insights (potential_false_positive_reasons, cross_section_reasoning)
        review_insights_html = ""
        for contrib in analyst_contributions:
            reviews = contrib.get("aggregate_scores", {}).get("reviews", [])
            if not reviews:
                # Try to get from issue directly
                reviews = issue.get("reviews", [])
            
            fp_reasons = []
            cross_reasonings = []
            
            for review in reviews:
                eval_data = review.get("evaluation", {})
                if eval_data:
                    # Collect false positive reasons
                    fp = eval_data.get("potential_false_positive_reasons", [])
                    if fp:
                        fp_reasons.extend([r for r in fp if r and r not in fp_reasons])
                    
                    # Collect cross-section reasoning
                    cs = eval_data.get("cross_section_reasoning", "")
                    if cs and cs not in cross_reasonings:
                        cross_reasonings.append(cs)
            
            if fp_reasons or cross_reasonings:
                fp_html = ""
                if fp_reasons:
                    fp_items = "".join([f'<li style="margin-bottom:.25rem;color:#b45309">{html_module.escape(r)}</li>' for r in fp_reasons[:5]])
                    fp_html = f'''<div style="margin-bottom:.75rem">
                        <h5 style="font-size:.8rem;color:#92400e;margin-bottom:.4rem">⚠️ Raisons potentielles de faux positif</h5>
                        <ul style="list-style:none;font-size:.85rem;padding-left:0;margin:0">{fp_items}</ul>
                    </div>'''
                
                cs_html = ""
                if cross_reasonings:
                    cs_items = "".join([f'<p style="margin-bottom:.25rem;color:#6b7280">{html_module.escape(r)}</p>' for r in cross_reasonings[:3]])
                    cs_html = f'''<div style="margin-bottom:.75rem">
                        <h5 style="font-size:.8rem;color:#4b5563;margin-bottom:.4rem">🔍 Analyse cross-section</h5>
                        <div style="font-size:.85rem">{cs_items}</div>
                    </div>'''
                
                if fp_html or cs_html:
                    review_insights_html = f'''<div style="background:#fffbeb;border:1px solid #fcd34d;border-radius:.5rem;padding:1rem;margin-bottom:1rem">
                        <div style="font-weight:600;color:#92400e;margin-bottom:.75rem;font-size:.9rem">📋 Insights des Reviewers</div>
                        {fp_html}{cs_html}
                    </div>'''
                break  # Only need to extract once
        
        # Analyst details
        analysts_html = ""
        for idx, contrib in enumerate(analyst_contributions):
            a_name = html_module.escape(contrib.get("analyst", "Unknown"))
            a_id = html_module.escape(contrib.get("issue_id", "N/A"))
            a_sev = contrib.get("severity", "MEDIUM")
            a_col = severity_colors.get(a_sev, "#6b7280")
            a_desc = html_module.escape(contrib.get("description", "No description"))
            a_rec = html_module.escape(contrib.get("recommendation", ""))
            a_pages = ", ".join(contrib.get("page_references", [])) or "N/A"
            a_evid = "".join([f'<li style="background:#f3f4f6;padding:.4rem .6rem;margin-bottom:.3rem;border-radius:.25rem;border-left:3px solid #ca8a04"><code style="word-break:break-word;font-size:.8rem">{html_module.escape(str(e))}</code></li>' for e in contrib.get("evidence", [])]) or "<li>No evidence</li>"
            a_scores = contrib.get("aggregate_scores", {})
            a_val = a_scores.get("avg_validity", 0)
            
            # Extract review details (potential FP reasons and cross-section reasoning)
            a_reviews = a_scores.get("reviews", []) if a_scores else []
            fp_reasons = []
            cross_reasoning = []
            for rev in a_reviews:
                eval_data = rev.get("evaluation", {}) if isinstance(rev, dict) else {}
                if eval_data:
                    # Get potential false positive reasons
                    fp_list = eval_data.get("potential_false_positive_reasons", [])
                    if fp_list and isinstance(fp_list, list):
                        fp_reasons.extend([r for r in fp_list if r and str(r).strip()])
                    # Get cross-section reasoning
                    cs_reason = eval_data.get("cross_section_reasoning", "")
                    if cs_reason and str(cs_reason).strip():
                        cross_reasoning.append(str(cs_reason).strip())
            
            # Build FP reasons HTML
            fp_html = ""
            if fp_reasons:
                fp_items = "".join([f'<li style="color:#b45309;font-size:.8rem;margin-bottom:.25rem">⚠️ {html_module.escape(str(r))}</li>' for r in fp_reasons[:3]])
                fp_html = f'''<div style="margin-top:1rem;background:#fef3c7;border:1px solid #f59e0b;border-radius:.5rem;padding:.75rem">
                        <h5 style="font-size:.8rem;color:#92400e;margin-bottom:.4rem">⚠️ Risques de Faux Positif Identifiés</h5>
                        <ul style="list-style:none;margin:0;padding:0">{fp_items}</ul>
                    </div>'''
            
            # Build cross-section reasoning HTML
            cs_html = ""
            if cross_reasoning:
                cs_text = html_module.escape(cross_reasoning[0])
                cs_html = f'''<div style="margin-top:1rem;background:#ede9fe;border:1px solid #8b5cf6;border-radius:.5rem;padding:.75rem">
                        <h5 style="font-size:.8rem;color:#6d28d9;margin-bottom:.4rem">🔀 Analyse Cross-Section</h5>
                        <p style="font-size:.8rem;color:#5b21b6;margin:0">{cs_text}</p>
                    </div>'''
            
            border_style = "border:2px solid #2563eb" if idx == 0 else "border:1px solid #e5e7eb"
            analysts_html += f'''<div style="{border_style};border-radius:.5rem;margin-bottom:.75rem;overflow:hidden">
                <div style="background:#f9fafb;padding:.75rem 1rem;display:flex;align-items:center;gap:.75rem;flex-wrap:wrap;border-bottom:1px solid #e5e7eb">
                    <span style="font-weight:600;color:#1f2937">{a_name}</span>
                    <span style="font-family:monospace;background:#e5e7eb;padding:.1rem .3rem;border-radius:.25rem;font-size:.75rem;color:#4b5563">{a_id}</span>
                    <span style="background:{a_col};color:#fff;padding:.1rem .4rem;border-radius:.5rem;font-size:.65rem;font-weight:600">{a_sev}</span>
                    <span style="font-size:.75rem;color:#6b7280;margin-left:auto">Validity: {a_val:.0%}</span>
                </div>
                <div style="padding:1rem">
                    <div style="margin-bottom:1rem"><h5 style="font-size:.8rem;color:#4b5563;margin-bottom:.4rem">📝 Description</h5><p style="font-size:.85rem;color:#374151">{a_desc}</p></div>
                    <div style="margin-bottom:1rem"><h5 style="font-size:.8rem;color:#4b5563;margin-bottom:.4rem">📄 Pages</h5><p style="font-size:.85rem;color:#374151">{a_pages}</p></div>
                    <div style="margin-bottom:1rem"><h5 style="font-size:.8rem;color:#4b5563;margin-bottom:.4rem">🔍 Evidence</h5><ul style="list-style:none;font-size:.8rem;margin:0;padding:0">{a_evid}</ul></div>
                    {f'<div style="margin-bottom:1rem"><h5 style="font-size:.8rem;color:#4b5563;margin-bottom:.4rem">💡 Recommendation</h5><p style="font-size:.85rem;color:#374151">{a_rec}</p></div>' if a_rec else ''}
                    {fp_html}
                    {cs_html}
                </div>
            </div>'''
        
        if not analysts_html:
            analysts_html = '<p style="color:#4b5563;font-style:italic">No analyst contributions available.</p>'
        
        all_pages = issue.get("all_page_references", issue.get("page_references", []))
        pages_display = ", ".join(str(p) for p in all_pages) or "N/A"
        
        grouping = issue.get("grouping_rationale", "")
        grouping_html = f'<div style="background:rgba(37,99,235,.1);border-left:3px solid #2563eb;padding:.75rem 1rem;margin-bottom:1rem;font-size:.85rem;border-radius:0 .5rem .5rem 0"><strong>🔗 Regroupement:</strong> {html_module.escape(grouping)}</div>' if grouping and num_analysts > 1 else ""
        
        issues_html += f'''<div style="{card_style};border-radius:.75rem;padding:1.5rem;margin-bottom:1.5rem">
            <div style="display:flex;align-items:center;gap:.75rem;margin-bottom:.75rem;flex-wrap:wrap">
                <span style="background:{color};color:#fff;padding:.25rem .75rem;border-radius:1rem;font-size:.75rem;font-weight:600;text-transform:uppercase">{severity}</span>
                <span style="font-family:monospace;background:#f3f4f6;padding:.25rem .5rem;border-radius:.25rem;font-size:.85rem">{issue.get('final_id', 'N/A')}</span>
                <span style="color:#4b5563;font-size:.85rem">{issue_type}</span>
                {gw_badge}{analysts_badge}
            </div>
            <h3 style="color:#1f2937;margin-bottom:.5rem;font-size:1.1rem">{html_module.escape(issue.get('title', 'Untitled'))}</h3>
            {grouping_html}
            <div style="background:#f9fafb;padding:.75rem 1rem;border-radius:.5rem;margin-bottom:1rem;display:flex;flex-wrap:wrap;gap:1rem">
                <div><span style="font-size:.8rem;color:#4b5563">📄 Pages:</span> <span style="font-size:.85rem;font-weight:500">{pages_display}</span></div>
                <div><span style="font-size:.8rem;color:#4b5563">🤝 Consensus:</span> <span style="font-size:.85rem;font-weight:500">Val {validity_score:.0%} | Ev {evidence_score:.0%} | {confidence}</span></div>
            </div>
            {review_insights_html}
            <div style="margin:1.5rem 0">
                <h4 style="color:#374151;margin-bottom:1rem;font-size:.95rem">👥 Contributions des Analystes</h4>
                {analysts_html}
            </div>
        </div>'''
    
    if not issues_html:
        issues_html = '<p style="color:#4b5563;font-style:italic;text-align:center;padding:1rem">No confirmed issues.</p>'
    
    # Dismissed issues
    dismissed_html = ""
    for d in dismissed_issues:
        d_id = d.get("issue_id", d.get("original_id", "N/A"))
        d_reason = d.get("dismissal_reason", d.get("reason_dismissed", d.get("_filter_reason", "")))
        d_title = d.get("title", "")
        d_type = d.get("type", "N/A")
        d_val = d.get("validity_score", d.get("aggregate_scores", {}).get("avg_validity", 0))
        dismissed_html += f'''<div style="padding:.75rem 1rem;background:#f9fafb;border-radius:.5rem;margin-bottom:.5rem;display:flex;flex-wrap:wrap;gap:.5rem;align-items:center">
            <span style="font-family:monospace;background:#e5e7eb;padding:.1rem .4rem;border-radius:.25rem;font-size:.8rem">{d_id}</span>
            <span style="color:#6b7280;font-size:.8rem">{d_type}</span>
            <span style="color:#6b7280;font-size:.8rem">Val: {d_val:.0%}</span>
            <span style="font-weight:500;flex:1">{html_module.escape(d_title)}</span>
            <span style="color:#4b5563;font-size:.85rem;width:100%">{html_module.escape(d_reason)}</span>
        </div>'''
    if not dismissed_html:
        dismissed_html = '<p style="color:#4b5563;font-style:italic;text-align:center;padding:1rem">No issues dismissed.</p>'
    
    # Key concerns
    concerns_html = "".join([f'<li style="padding:.75rem 1rem;background:#f9fafb;border-left:4px solid #2563eb;margin-bottom:.5rem;border-radius:0 .5rem .5rem 0">{html_module.escape(c)}</li>' for c in summary.get("key_concerns", [])]) or "<li>None</li>"
    
    # Analysts grid
    analysts_grid = "".join([f'<div style="background:#f9fafb;padding:1rem;border-radius:.5rem;text-align:center"><strong>{html_module.escape(a.get("analyst", ""))}</strong><br>{a.get("total_issues", 0)} issues</div>' for a in phase1_analyses])
    council_section = f'<div style="background:#fff;border-radius:.75rem;padding:2rem;margin-bottom:2rem;box-shadow:0 1px 3px rgba(0,0,0,.1)"><h2 style="border-bottom:2px solid #e5e7eb;padding-bottom:.75rem;margin-bottom:1rem">👥 Council</h2><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:1rem">{analysts_grid}</div></div>' if analysts_grid else ""
    
    # Metadata
    total_pages = metadata.get("total_pages", "N/A")
    num_analysts_meta = metadata.get("num_analysts", "N/A")
    num_reviewers = metadata.get("num_reviewers", "N/A")
    pre_filtered = summary.get("pre_filtered_count", 0)
    
    try:
        gen_at = metadata.get("generated_at", "")
        formatted_date = datetime.fromisoformat(gen_at.replace('Z', '+00:00')).strftime('%Y-%m-%d %H:%M') if gen_at else datetime.now().strftime('%Y-%m-%d %H:%M')
    except:
        formatted_date = datetime.now().strftime('%Y-%m-%d %H:%M')
    
    pre_filtered_badge = f'<span style="background:rgba(255,255,255,.2);padding:.4rem .8rem;border-radius:.5rem;font-size:.85rem">🔽 {pre_filtered} pre-filtered</span>' if pre_filtered > 0 else ""
    verify_badge = f'<span style="background:rgba(255,255,255,.2);padding:.4rem .8rem;border-radius:.5rem;font-size:.85rem">🔍 {total_needs_verification} to verify</span>' if total_needs_verification > 0 else ""

    return f'''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{html_module.escape(title)}</title>
<style>
*{{margin:0;padding:0;box-sizing:border-box}}
body{{font-family:system-ui,-apple-system,sans-serif;background:#f9fafb;color:#1f2937;line-height:1.6}}
.container{{max-width:1200px;margin:0 auto;padding:2rem}}
@media(max-width:768px){{.container{{padding:1rem}}}}
</style>
</head>
<body>
<div class="container">

<div style="background:linear-gradient(135deg,#2563eb,#1d4ed8);color:#fff;padding:2.5rem;border-radius:1rem;margin-bottom:2rem;box-shadow:0 10px 40px rgba(37,99,235,.3)">
    <h1 style="font-size:2rem;margin-bottom:.5rem">🏛️ {html_module.escape(title)} <small style="font-size:.5em;opacity:.8">v2.0</small></h1>
    <p>Multi-Model Analysis with Peer Review</p>
    <div style="display:flex;gap:1.5rem;margin-top:1rem;flex-wrap:wrap">
        <span style="background:rgba(255,255,255,.2);padding:.4rem .8rem;border-radius:.5rem;font-size:.85rem">📄 {total_pages} pages</span>
        <span style="background:rgba(255,255,255,.2);padding:.4rem .8rem;border-radius:.5rem;font-size:.85rem">👥 {num_analysts_meta} analysts</span>
        <span style="background:rgba(255,255,255,.2);padding:.4rem .8rem;border-radius:.5rem;font-size:.85rem">📝 {num_reviewers} reviewers</span>
        <span style="background:rgba(255,255,255,.2);padding:.4rem .8rem;border-radius:.5rem;font-size:.85rem">📅 {formatted_date}</span>
        {pre_filtered_badge}
        {verify_badge}
    </div>
</div>

{greenwashing_alert}

<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:1rem;margin-bottom:2rem">
    <div style="background:#fff;padding:1.25rem;border-radius:.75rem;text-align:center;box-shadow:0 1px 3px rgba(0,0,0,.1)"><div style="font-size:2rem;font-weight:700;color:#2563eb">{summary.get('total_confirmed_issues', 0)}</div><div style="color:#4b5563;font-size:.85rem">Total Issues</div></div>
    <div style="background:#fff;padding:1.25rem;border-radius:.75rem;text-align:center;box-shadow:0 1px 3px rgba(0,0,0,.1)"><div style="font-size:2rem;font-weight:700;color:#dc2626">{summary.get('critical_issues', 0)}</div><div style="color:#4b5563;font-size:.85rem">Critical</div></div>
    <div style="background:#fff;padding:1.25rem;border-radius:.75rem;text-align:center;box-shadow:0 1px 3px rgba(0,0,0,.1)"><div style="font-size:2rem;font-weight:700;color:#ea580c">{summary.get('high_issues', 0)}</div><div style="color:#4b5563;font-size:.85rem">High</div></div>
    <div style="background:#fff;padding:1.25rem;border-radius:.75rem;text-align:center;box-shadow:0 1px 3px rgba(0,0,0,.1)"><div style="font-size:2rem;font-weight:700;color:#ca8a04">{summary.get('medium_issues', 0)}</div><div style="color:#4b5563;font-size:.85rem">Medium</div></div>
    <div style="background:#fff;padding:1.25rem;border-radius:.75rem;text-align:center;box-shadow:0 1px 3px rgba(0,0,0,.1)"><div style="font-size:2rem;font-weight:700;color:#16a34a">{summary.get('low_issues', 0)}</div><div style="color:#4b5563;font-size:.85rem">Low</div></div>
    <div style="background:#fff;padding:1.25rem;border-radius:.75rem;text-align:center;box-shadow:0 1px 3px rgba(0,0,0,.1)"><div style="font-size:2rem;font-weight:700;color:#8b5cf6">{total_needs_verification}</div><div style="color:#4b5563;font-size:.85rem">To Verify</div></div>
</div>

<div style="background:#fff;border-radius:.75rem;padding:2rem;margin-bottom:2rem;box-shadow:0 1px 3px rgba(0,0,0,.1)">
    <h2 style="border-bottom:2px solid #e5e7eb;padding-bottom:.75rem;margin-bottom:1rem">📋 Executive Summary</h2>
    {type_breakdown}
    <h3 style="margin:1rem 0 .75rem;color:#374151">Key Concerns</h3>
    <ul style="list-style:none">{concerns_html}</ul>
    <div style="background:#f9fafb;padding:1.5rem;border-radius:.75rem;border-left:4px solid #2563eb;margin-top:1rem">
        <strong>Overall Assessment:</strong><br><br>{html_module.escape(summary.get('overall_assessment', 'N/A'))}
    </div>
</div>

{verification_section}

<div style="background:#fff;border-radius:.75rem;padding:2rem;margin-bottom:2rem;box-shadow:0 1px 3px rgba(0,0,0,.1)">
    <h2 style="border-bottom:2px solid #e5e7eb;padding-bottom:.75rem;margin-bottom:1rem">✅ Confirmed Issues ({len(confirmed_issues)})</h2>
    {issues_html}
</div>

<div style="background:#fff;border-radius:.75rem;padding:2rem;margin-bottom:2rem;box-shadow:0 1px 3px rgba(0,0,0,.1)">
    <h2 style="border-bottom:2px solid #e5e7eb;padding-bottom:.75rem;margin-bottom:1rem">❌ Dismissed Issues ({len(dismissed_issues)})</h2>
    {dismissed_html}
</div>

{council_section}

<div style="text-align:center;padding:2rem;color:#4b5563;font-size:.85rem">
    <p>Generated by CSRD LLM Council Analyzer v2.0</p>
    <p>All intermediate outputs available in JSON format</p>
</div>

</div>
</body>
</html>'''


def main():
    parser = argparse.ArgumentParser(
        description="Generate HTML report from Phase 3 judgment JSON",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    # Basic usage
    python generate_html_report.py --json phase3_judgment.json
    
    # With document for page viewer
    python generate_html_report.py --json phase3_judgment.json --document report.json
    
    # Custom output and title
    python generate_html_report.py --json phase3_judgment.json -o my_report.html --title "Q4 CSRD Audit"
        """
    )
    
    parser.add_argument("--json", "-j", required=True,
                       help="Path to Phase 3 judgment JSON file")
    parser.add_argument("--document", "-d",
                       help="Path to original document JSON (optional, enables page viewer)")
    parser.add_argument("--output", "-o",
                       help="Output HTML file path (default: same as JSON with .html extension)")
    parser.add_argument("--title", "-t", default="CSRD Council Report",
                       help="Report title (default: 'CSRD Council Report')")
    parser.add_argument("--verbose", "-v", action="store_true",
                       help="Verbose output")
    
    args = parser.parse_args()
    
    # Validate input
    if not os.path.exists(args.json):
        print(f"❌ Error: JSON file not found: {args.json}")
        return 1
    
    # Default output path
    if not args.output:
        args.output = os.path.splitext(args.json)[0] + ".html"
    
    print(f"📄 Loading judgment: {args.json}")
    judgment = load_json_file(args.json)
    
    # Load document if provided
    document_pages = {}
    if args.document:
        print(f"📄 Loading document: {args.document}")
        document_pages = load_document_pages(args.document)
        if document_pages:
            print(f"   ✓ Loaded {len(document_pages)} pages")
        else:
            print(f"   ⚠️ No pages loaded (page viewer will be disabled)")
    
    # Extract metadata
    metadata = extract_metadata_from_judgment(judgment)
    phase1_analyses = extract_phase1_analyses(judgment)
    
    if args.verbose:
        print(f"\n📊 Report Statistics:")
        print(f"   Confirmed issues: {len(judgment.get('confirmed_issues', []))}")
        print(f"   Needs verification: {len(judgment.get('needs_verification', []))}")
        print(f"   Dismissed issues: {len(judgment.get('dismissed_issues', []))}")
        summary = judgment.get("executive_summary", {})
        if summary.get("greenwashing_count", 0) > 0:
            print(f"   🚨 Greenwashing issues: {summary.get('greenwashing_count')}")
    
    # Generate HTML
    print(f"\n🔨 Generating HTML report...")
    
    # Try to use the full html_generator if available
    try:
        from csrd_council_2.utils.html_generator import generate_html_report as gen_full
        html_content = gen_full(judgment, metadata, phase1_analyses, document_pages)
        print("   Using full HTML generator (with page viewer)")
    except ImportError:
        html_content = generate_html_report_standalone(judgment, metadata, phase1_analyses, document_pages, args.title)
        print("   Using standalone HTML generator")
    
    # Write output
    with open(args.output, 'w', encoding='utf-8') as f:
        f.write(html_content)
    
    print(f"\n✅ Report generated: {args.output}")
    print(f"   Open in browser to view")
    
    return 0


if __name__ == "__main__":
    sys.exit(main())