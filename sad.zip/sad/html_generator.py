"""
HTML Report Generator v2.0
==========================

Generates beautiful HTML reports from judgment JSON.

Updated for v2.0:
- New "needs_verification" section
- GREENWASHING special alerts and risk level
- Issue type breakdown visualization
- Cross-section risk indicators
- Enhanced confidence display
"""

import re
import html
from datetime import datetime
from typing import Dict, List, Optional


def markdown_to_html(text: str) -> str:
    """Convert markdown text to HTML."""
    if not text:
        return ""
    
    lines = text.split('\n')
    result_lines = []
    in_code_block = False
    in_table = False
    table_rows = []
    in_list = False
    list_type = None
    list_items = []
    
    def process_inline(line: str) -> str:
        line = re.sub(r'`([^`]+)`', r'<code>\1</code>', line)
        line = re.sub(r'\*\*([^*]+)\*\*', r'<strong>\1</strong>', line)
        line = re.sub(r'__([^_]+)__', r'<strong>\1</strong>', line)
        line = re.sub(r'(?<!\*)\*([^*]+)\*(?!\*)', r'<em>\1</em>', line)
        line = re.sub(r'(?<!_)_([^_]+)_(?!_)', r'<em>\1</em>', line)
        line = re.sub(r'\[([^\]]+)\]\(([^)]+)\)', r'<a href="\2">\1</a>', line)
        return line
    
    def flush_list():
        nonlocal in_list, list_items, list_type
        if list_items:
            tag = 'ol' if list_type == 'ordered' else 'ul'
            items_html = ''.join(f'<li>{item}</li>' for item in list_items)
            result_lines.append(f'<{tag} class="md-list">{items_html}</{tag}>')
            list_items = []
        in_list = False
        list_type = None
    
    def flush_table():
        nonlocal in_table, table_rows
        if table_rows:
            header = table_rows[0]
            body = table_rows[1:] if len(table_rows) > 1 else []
            body = [row for row in body if not all(cell.strip().replace('-', '').replace(':', '') == '' for cell in row)]
            header_html = ''.join(f'<th>{cell.strip()}</th>' for cell in header)
            body_html = ''.join('<tr>' + ''.join(f'<td>{cell.strip()}</td>' for cell in row) + '</tr>' for row in body)
            result_lines.append(f'<table class="md-table"><thead><tr>{header_html}</tr></thead><tbody>{body_html}</tbody></table>')
            table_rows = []
        in_table = False
    
    for line in lines:
        stripped = line.strip()
        
        if stripped.startswith('```'):
            if in_code_block:
                result_lines.append('</code></pre>')
                in_code_block = False
            else:
                flush_list()
                flush_table()
                lang = stripped[3:].strip()
                result_lines.append(f'<pre class="md-code-block"><code class="language-{lang}">')
                in_code_block = True
            continue
        
        if in_code_block:
            result_lines.append(html.escape(line))
            continue
        
        if not stripped:
            flush_list()
            flush_table()
            result_lines.append('<br>')
            continue
        
        if re.match(r'^(-{3,}|\*{3,}|_{3,})$', stripped):
            flush_list()
            flush_table()
            result_lines.append('<hr class="md-hr">')
            continue
        
        header_match = re.match(r'^(#{1,6})\s+(.+)$', stripped)
        if header_match:
            flush_list()
            flush_table()
            level = len(header_match.group(1))
            content = process_inline(html.escape(header_match.group(2)))
            result_lines.append(f'<h{level} class="md-header">{content}</h{level}>')
            continue
        
        if '|' in stripped and stripped.startswith('|'):
            flush_list()
            if not in_table:
                in_table = True
            cells = [cell.strip() for cell in stripped.split('|')[1:-1]]
            cells = [process_inline(html.escape(cell)) for cell in cells]
            table_rows.append(cells)
            continue
        elif in_table:
            flush_table()
        
        if stripped.startswith('>'):
            flush_list()
            flush_table()
            content = process_inline(html.escape(stripped[1:].strip()))
            result_lines.append(f'<blockquote class="md-blockquote">{content}</blockquote>')
            continue
        
        list_match = re.match(r'^[-*+]\s+(.+)$', stripped)
        if list_match:
            flush_table()
            if not in_list or list_type != 'unordered':
                flush_list()
                in_list = True
                list_type = 'unordered'
            list_items.append(process_inline(html.escape(list_match.group(1))))
            continue
        
        ordered_match = re.match(r'^(\d+)[.)]\s+(.+)$', stripped)
        if ordered_match:
            flush_table()
            if not in_list or list_type != 'ordered':
                flush_list()
                in_list = True
                list_type = 'ordered'
            list_items.append(process_inline(html.escape(ordered_match.group(2))))
            continue
        
        if in_list:
            flush_list()
        if in_table:
            flush_table()
        
        content = process_inline(html.escape(stripped))
        result_lines.append(f'<p class="md-para">{content}</p>')
    
    flush_list()
    flush_table()
    if in_code_block:
        result_lines.append('</code></pre>')
    
    return '\n'.join(result_lines)


def highlight_evidence_in_html(html_content: str, evidence_list: List[str]) -> str:
    """Highlight evidence phrases in HTML content."""
    if not evidence_list or not html_content:
        return html_content
    
    sorted_evidence = sorted(evidence_list, key=len, reverse=True)
    
    for evidence in sorted_evidence:
        if not evidence or len(evidence) < 5:
            continue
        
        evidence_clean = evidence.strip()
        pattern_text = re.escape(evidence_clean)
        pattern_text = re.sub(r'\\\s+', r'\\s+', pattern_text)
        
        try:
            def replace_outside_tags(match):
                return f'<mark class="evidence-highlight">{match.group(0)}</mark>'
            
            parts = re.split(r'(<[^>]+>)', html_content)
            for i, part in enumerate(parts):
                if not part.startswith('<'):
                    parts[i] = re.sub(pattern_text, replace_outside_tags, part, flags=re.IGNORECASE)
            html_content = ''.join(parts)
        except re.error:
            if evidence_clean.lower() in html_content.lower():
                idx = html_content.lower().find(evidence_clean.lower())
                if idx >= 0:
                    original = html_content[idx:idx+len(evidence_clean)]
                    html_content = html_content.replace(original, f'<mark class="evidence-highlight">{original}</mark>', 1)
    
    return html_content


def extract_page_numbers_from_refs(page_references: List[str]) -> List[int]:
    """Extract page numbers from page reference strings."""
    page_nums = set()
    for ref in page_references:
        nums = re.findall(r'\d+', str(ref))
        page_nums.update(int(n) for n in nums)
    return sorted(page_nums)


def generate_page_viewer_html(issue: Dict, document_pages: Dict[int, str]) -> str:
    """Generate HTML for the source pages viewer."""
    page_refs = issue.get("page_references", [])
    evidence_list = issue.get("evidence", [])
    
    if not page_refs or not document_pages:
        return ""
    
    page_nums = extract_page_numbers_from_refs(page_refs)
    if not page_nums:
        return ""
    
    tabs_html = ""
    content_html = ""
    
    for idx, page_num in enumerate(page_nums):
        page_content = document_pages.get(page_num, "")
        if not page_content:
            continue
        
        html_content = markdown_to_html(page_content)
        highlighted_content = highlight_evidence_in_html(html_content, evidence_list)
        
        active_class = "active" if idx == 0 else ""
        issue_id = issue.get('issue_id', issue.get('final_id', 'unknown'))
        safe_issue_id = re.sub(r'[^a-zA-Z0-9_-]', '_', str(issue_id))
        tab_id = f"{safe_issue_id}-page-{page_num}"
        
        tabs_html += f'<button class="page-tab {active_class}" onclick="showPage(\'{tab_id}\', this)" data-page="{page_num}">Page {page_num}</button>'
        content_html += f'''<div id="{tab_id}" class="page-content {active_class}">
            <div class="page-header"><span class="page-number">📄 Page {page_num}</span><span class="highlight-legend"><mark class="evidence-highlight">Evidence</mark></span></div>
            <div class="page-text">{highlighted_content}</div></div>'''
    
    if not tabs_html:
        return ""
    
    return f'<div class="source-pages-viewer"><h4>📑 Source Pages</h4><div class="page-tabs">{tabs_html}</div><div class="page-contents">{content_html}</div></div>'


def generate_html_report(
    judgment: Dict,
    metadata: Dict = None,
    phase1_analyses: List[Dict] = None,
    document_pages: Dict[int, str] = None
) -> str:
    """Generate HTML report from judgment data."""
    metadata = metadata or {}
    phase1_analyses = phase1_analyses or []
    document_pages = document_pages or {}
    
    summary = judgment.get("executive_summary", {})
    confirmed_issues = judgment.get("confirmed_issues", [])
    dismissed_issues = judgment.get("dismissed_issues", [])
    needs_verification = judgment.get("needs_verification", [])
    conflicts = judgment.get("conflicts_resolved", [])
    
    severity_colors = {"CRITICAL": "#dc2626", "HIGH": "#ea580c", "MEDIUM": "#ca8a04", "LOW": "#16a34a"}
    
    # v2.0: New fields
    by_type = summary.get("by_type", {})
    greenwashing_count = summary.get("greenwashing_count", 0)
    greenwashing_risk = summary.get("greenwashing_risk_level", "LOW")
    total_needs_verification = summary.get("total_needs_verification", len(needs_verification))
    
    # Generate greenwashing alert
    greenwashing_alert_html = ""
    if greenwashing_count > 0:
        risk_colors = {"CRITICAL": "#dc2626", "HIGH": "#ea580c", "MEDIUM": "#ca8a04", "LOW": "#22c55e"}
        gw_color = risk_colors.get(greenwashing_risk, "#ca8a04")
        greenwashing_alert_html = f'''
        <div class="greenwashing-alert" style="border-color: {gw_color}">
            <div class="greenwashing-icon">🚨</div>
            <div class="greenwashing-content">
                <div class="greenwashing-title">GREENWASHING DÉTECTÉ <span class="gw-risk-badge" style="background:{gw_color}">{greenwashing_risk}</span></div>
                <div class="greenwashing-message">{greenwashing_count} issue(s) de greenwashing identifiée(s). Risque réglementaire à évaluer.</div>
            </div>
        </div>'''
    
    # Generate type breakdown
    type_breakdown_html = ""
    if by_type:
        type_colors = {
            "GREENWASHING": "#dc2626", "NUMERIC_INCONSISTENCY": "#ea580c", "REGULATORY_GAP": "#dc2626",
            "LOGICAL_CONTRADICTION": "#ea580c", "MISSING_INFORMATION": "#ca8a04", "AMBIGUOUS_STATEMENT": "#eab308",
            "CONCEPTUAL_INCONSISTENCY": "#f59e0b", "CROSS_REFERENCE_ERROR": "#22c55e"
        }
        total = sum(by_type.values()) or 1
        bars = ""
        for t, c in sorted(by_type.items(), key=lambda x: -x[1]):
            pct = (c / total) * 100
            col = type_colors.get(t, "#6b7280")
            icon = "🚨 " if t == "GREENWASHING" else ""
            bars += f'<div class="type-row"><span class="type-name">{icon}{t.replace("_", " ").title()}</span><span class="type-count">{c}</span><div class="type-bar"><div class="type-fill" style="width:{pct}%;background:{col}"></div></div></div>'
        type_breakdown_html = f'<div class="type-breakdown"><h4>📊 Répartition par Type</h4>{bars}</div>'
    
    # Generate needs verification section
    verification_html = ""
    if needs_verification:
        items = ""
        for v in needs_verification:
            vid = v.get("issue_id", "N/A")
            vtitle = html.escape(v.get("title", ""))
            vtype = v.get("type", "N/A")
            vreason = html.escape(v.get("verification_reason", v.get("_filter_reason", "À vérifier")))
            vcheck = html.escape(v.get("what_to_check", "Vérifier dans les autres sections"))
            vvalid = v.get("validity_score", 0)
            vrisk = v.get("cross_section_risk", "UNKNOWN")
            risk_col = {"HIGH": "#dc2626", "MEDIUM": "#ca8a04", "LOW": "#22c55e"}.get(vrisk, "#6b7280")
            items += f'''<div class="verify-item">
                <div class="verify-header"><span class="verify-id">{vid}</span><span class="verify-type">{vtype}</span>
                <span class="verify-validity">Validity: {vvalid:.0%}</span><span class="cross-risk" style="background:{risk_col}">Cross: {vrisk}</span></div>
                <div class="verify-title">{vtitle}</div>
                <div class="verify-reason"><strong>Raison:</strong> {vreason}</div>
                <div class="verify-check"><strong>À vérifier:</strong> {vcheck}</div></div>'''
        verification_html = f'''<div class="section verify-section">
            <h2>🔍 À Vérifier ({len(needs_verification)})</h2>
            <p class="section-desc">Issues avec validité moyenne ou risque de faux positif. Vérification manuelle requise.</p>
            {items}</div>'''
    
    # Build confirmed issues HTML
    issues_html = ""
    for issue in confirmed_issues:
        severity = issue.get("final_severity", issue.get("severity", "MEDIUM"))
        issue_type = issue.get("type", "N/A")
        color = severity_colors.get(severity, "#6b7280")
        consensus = issue.get("consensus", {})
        review_scores = consensus.get("review_scores", {})
        validity_score = review_scores.get("validity", 0)
        evidence_score = review_scores.get("evidence", 0)
        confidence = consensus.get("confidence", "N/A")
        
        is_greenwashing = issue_type == "GREENWASHING"
        card_class = "issue-card greenwashing-card" if is_greenwashing else "issue-card"
        gw_badge = '<span class="gw-badge">🚨 GREENWASHING</span>' if is_greenwashing else ""
        
        analyst_contributions = issue.get("analyst_contributions", [])
        num_analysts = len(analyst_contributions)
        analysts_badge = f'<span class="analysts-count">{num_analysts} analyste{"s" if num_analysts > 1 else ""}</span>' if num_analysts > 0 else ""
        
        # Analyst sections
        analysts_html = ""
        if analyst_contributions:
            for idx, contrib in enumerate(analyst_contributions):
                a_name = html.escape(contrib.get("analyst", "Unknown"))
                a_id = html.escape(contrib.get("issue_id", "N/A"))
                a_sev = contrib.get("severity", "MEDIUM")
                a_col = severity_colors.get(a_sev, "#6b7280")
                a_desc = html.escape(contrib.get("description", "No description"))
                a_rec = html.escape(contrib.get("recommendation", "No recommendation"))
                a_conf = contrib.get("confidence", "MEDIUM")
                a_pages = ", ".join(contrib.get("page_references", [])) or "N/A"
                a_evid = "".join([f'<li><code>{html.escape(str(e))}</code></li>' for e in contrib.get("evidence", [])]) or "<li>No evidence</li>"
                a_scores = contrib.get("aggregate_scores", {})
                a_val = a_scores.get("avg_validity", 0)
                a_ev = a_scores.get("avg_evidence", 0)
                
                analysts_html += f'''<div class="analyst-contrib {'first' if idx == 0 else ''}">
                    <div class="contrib-header">
                        <span class="a-name">{a_name}</span><span class="a-id">{a_id}</span>
                        <span class="sev-small" style="background:{a_col}">{a_sev}</span>
                        <span class="conf-badge">{a_conf}</span>
                        <span class="a-scores">Val: {a_val:.0%} | Ev: {a_ev:.0%}</span>
                    </div>
                    <div class="contrib-body">
                        <div class="c-sec"><h5>📝 Description</h5><p>{a_desc}</p></div>
                        <div class="c-sec"><h5>📄 Pages</h5><p>{a_pages}</p></div>
                        <div class="c-sec"><h5>🔍 Evidence</h5><ul class="ev-list">{a_evid}</ul></div>
                        <div class="c-sec"><h5>💡 Recommendation</h5><p>{a_rec}</p></div>
                    </div></div>'''
        else:
            analysts_html = '<p class="empty">No analyst contributions available.</p>'
        
        all_pages = issue.get("all_page_references", issue.get("page_references", []))
        pages_display = ", ".join(all_pages) or "N/A"
        
        grouping_html = ""
        grouping = issue.get("grouping_rationale", "")
        if grouping and num_analysts > 1:
            grouping_html = f'<div class="grouping"><strong>🔗 Regroupement:</strong> {html.escape(grouping)}</div>'
        
        pages_viewer = generate_page_viewer_html({**issue, "page_references": all_pages}, document_pages)
        
        issues_html += f'''<div class="{card_class}">
            <div class="issue-header">
                <span class="sev-badge" style="background:{color}">{severity}</span>
                <span class="issue-id">{issue.get('final_id', 'N/A')}</span>
                <span class="issue-type">{issue_type}</span>
                {gw_badge}{analysts_badge}
            </div>
            <h3 class="issue-title">{html.escape(issue.get('title', 'Untitled'))}</h3>
            {grouping_html}
            <div class="issue-summary">
                <div class="sum-item"><span class="sum-label">📄 Pages:</span><span class="sum-val">{pages_display}</span></div>
                <div class="sum-item"><span class="sum-label">🤝 Consensus:</span><span class="sum-val">Val {validity_score:.0%} | Ev {evidence_score:.0%} | {confidence}</span></div>
            </div>
            <div class="analysts-section"><h4>👥 Contributions des Analystes</h4>{analysts_html}</div>
            {pages_viewer}
        </div>'''
    
    # Dismissed issues
    dismissed_html = ""
    for d in dismissed_issues:
        d_id = d.get("issue_id", d.get("original_id", "N/A"))
        d_reason = d.get("dismissal_reason", d.get("reason_dismissed", d.get("_filter_reason", "")))
        d_title = d.get("title", "")
        d_type = d.get("type", "N/A")
        d_val = d.get("validity_score", d.get("aggregate_scores", {}).get("avg_validity", 0))
        dismissed_html += f'''<div class="dismissed-item">
            <span class="d-id">{d_id}</span><span class="d-type">{d_type}</span><span class="d-val">Val: {d_val:.0%}</span>
            <span class="d-title">{html.escape(d_title)}</span><span class="d-reason">{html.escape(d_reason)}</span></div>'''
    if not dismissed_html:
        dismissed_html = '<p class="empty">No issues dismissed.</p>'
    
    # Conflicts
    conflicts_html = "".join([f'<div class="conflict-item"><strong>Issue:</strong> {html.escape(c.get("issue_summary", ""))}<br><strong>Resolution:</strong> {html.escape(c.get("resolution", ""))}</div>' for c in conflicts]) or '<p class="empty">No conflicts.</p>'
    
    # Key concerns
    concerns_html = "".join([f"<li>{html.escape(c)}</li>" for c in summary.get("key_concerns", [])]) or "<li>None</li>"
    
    # Analysts grid
    analysts_grid = "".join([f'<div class="analyst-card"><strong>{html.escape(a.get("analyst", ""))}</strong><br>{a.get("total_issues", 0)} issues</div>' for a in phase1_analyses])
    council_section = f'<div class="section"><h2>👥 Council</h2><div class="analysts-grid">{analysts_grid}</div></div>' if analysts_grid else ""
    
    # Metadata
    total_pages = metadata.get("total_pages", "N/A")
    num_analysts = metadata.get("num_analysts", "N/A")
    num_reviewers = metadata.get("num_reviewers", "N/A")
    pre_filtered = summary.get("pre_filtered_count", 0)
    
    try:
        gen_at = metadata.get("generated_at", "")
        formatted_date = datetime.fromisoformat(gen_at.replace('Z', '+00:00')).strftime('%Y-%m-%d %H:%M') if gen_at else datetime.now().strftime('%Y-%m-%d %H:%M')
    except:
        formatted_date = datetime.now().strftime('%Y-%m-%d %H:%M')
    
    pre_filtered_badge = f'<span>🔽 {pre_filtered} pre-filtered</span>' if pre_filtered > 0 else ""
    verify_badge = f'<span>🔍 {total_needs_verification} to verify</span>' if total_needs_verification > 0 else ""

    return f'''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>CSRD Council Report v2.0</title>
<style>
:root{{--primary:#2563eb;--danger:#dc2626;--warning:#ca8a04;--success:#16a34a;--orange:#ea580c;--gray-50:#f9fafb;--gray-100:#f3f4f6;--gray-200:#e5e7eb;--gray-600:#4b5563;--gray-700:#374151;--gray-800:#1f2937;--highlight:#fef08a}}
*{{margin:0;padding:0;box-sizing:border-box}}
body{{font-family:system-ui,sans-serif;background:var(--gray-50);color:var(--gray-800);line-height:1.6}}
.container{{max-width:1200px;margin:0 auto;padding:2rem}}
.header{{background:linear-gradient(135deg,var(--primary),#1d4ed8);color:#fff;padding:2.5rem;border-radius:1rem;margin-bottom:2rem;box-shadow:0 10px 40px rgba(37,99,235,.3)}}
.header h1{{font-size:2rem;margin-bottom:.5rem}}
.header .meta{{display:flex;gap:1.5rem;margin-top:1rem;flex-wrap:wrap}}
.header .meta span{{background:rgba(255,255,255,.2);padding:.4rem .8rem;border-radius:.5rem;font-size:.85rem}}
.summary-grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:1rem;margin-bottom:2rem}}
.summary-card{{background:#fff;padding:1.25rem;border-radius:.75rem;text-align:center;box-shadow:0 1px 3px rgba(0,0,0,.1)}}
.summary-card .number{{font-size:2rem;font-weight:700;color:var(--primary)}}
.summary-card.critical .number{{color:var(--danger)}}.summary-card.high .number{{color:var(--orange)}}.summary-card.medium .number{{color:var(--warning)}}.summary-card.low .number{{color:var(--success)}}.summary-card.verify .number{{color:#8b5cf6}}
.summary-card .label{{color:var(--gray-600);font-size:.85rem}}
.section{{background:#fff;border-radius:.75rem;padding:2rem;margin-bottom:2rem;box-shadow:0 1px 3px rgba(0,0,0,.1)}}
.section h2{{border-bottom:2px solid var(--gray-200);padding-bottom:.75rem;margin-bottom:1rem}}
.section-desc{{color:var(--gray-600);margin-bottom:1rem;font-size:.9rem}}

/* Greenwashing Alert */
.greenwashing-alert{{display:flex;gap:1rem;align-items:center;background:linear-gradient(135deg,#fef2f2,#fff);border:2px solid var(--danger);border-radius:.75rem;padding:1.5rem;margin-bottom:2rem}}
.greenwashing-icon{{font-size:2.5rem}}
.greenwashing-title{{font-weight:700;color:var(--danger);font-size:1.1rem;display:flex;align-items:center;gap:.75rem}}
.gw-risk-badge{{color:#fff;padding:.2rem .6rem;border-radius:1rem;font-size:.7rem}}
.greenwashing-message{{color:var(--gray-700);margin-top:.25rem}}

/* Type Breakdown */
.type-breakdown{{background:var(--gray-50);padding:1.25rem;border-radius:.75rem;margin-bottom:1.5rem}}
.type-breakdown h4{{margin-bottom:1rem;color:var(--gray-700)}}
.type-row{{display:flex;align-items:center;gap:.75rem;margin-bottom:.5rem}}
.type-name{{width:200px;font-size:.85rem;color:var(--gray-700)}}
.type-count{{width:30px;text-align:right;font-weight:600;font-size:.85rem}}
.type-bar{{flex:1;height:8px;background:var(--gray-200);border-radius:4px;overflow:hidden}}
.type-fill{{height:100%;border-radius:4px}}

/* Verification Section */
.verify-section{{border-left:4px solid #8b5cf6}}
.verify-item{{border:1px solid var(--gray-200);border-radius:.5rem;padding:1rem;margin-bottom:.75rem;background:var(--gray-50)}}
.verify-header{{display:flex;flex-wrap:wrap;gap:.5rem;align-items:center;margin-bottom:.5rem}}
.verify-id{{font-family:monospace;background:var(--gray-200);padding:.15rem .4rem;border-radius:.25rem;font-size:.8rem}}
.verify-type{{color:var(--gray-600);font-size:.8rem}}
.verify-validity{{font-size:.8rem;color:var(--gray-600)}}
.cross-risk{{color:#fff;padding:.1rem .4rem;border-radius:.25rem;font-size:.7rem}}
.verify-title{{font-weight:600;margin-bottom:.5rem}}
.verify-reason,.verify-check{{font-size:.85rem;color:var(--gray-600);margin-top:.25rem}}

/* Issue Cards */
.issue-card{{border:1px solid var(--gray-200);border-radius:.75rem;padding:1.5rem;margin-bottom:1.5rem}}
.issue-card:hover{{box-shadow:0 4px 12px rgba(0,0,0,.1)}}
.issue-card.greenwashing-card{{border:2px solid var(--danger);background:linear-gradient(135deg,#fef2f2,#fff)}}
.issue-header{{display:flex;align-items:center;gap:.75rem;margin-bottom:.75rem;flex-wrap:wrap}}
.sev-badge{{color:#fff;padding:.25rem .75rem;border-radius:1rem;font-size:.75rem;font-weight:600;text-transform:uppercase}}
.issue-id{{font-family:monospace;background:var(--gray-100);padding:.25rem .5rem;border-radius:.25rem;font-size:.85rem}}
.issue-type{{color:var(--gray-600);font-size:.85rem}}
.gw-badge{{background:var(--danger);color:#fff;padding:.2rem .6rem;border-radius:1rem;font-size:.7rem;font-weight:600}}
.analysts-count{{background:var(--primary);color:#fff;padding:.2rem .6rem;border-radius:1rem;font-size:.7rem;font-weight:600}}
.issue-title{{color:var(--gray-800);margin-bottom:.5rem;font-size:1.1rem}}
.issue-summary{{background:var(--gray-50);padding:.75rem 1rem;border-radius:.5rem;margin-bottom:1rem;display:flex;flex-wrap:wrap;gap:1rem}}
.sum-item{{display:flex;gap:.5rem;align-items:center}}
.sum-label{{font-size:.8rem;color:var(--gray-600)}}.sum-val{{font-size:.85rem;font-weight:500}}
.grouping{{background:rgba(37,99,235,.1);border-left:3px solid var(--primary);padding:.75rem 1rem;margin-bottom:1rem;font-size:.85rem;border-radius:0 .5rem .5rem 0}}

/* Analyst Contributions */
.analysts-section{{margin:1.5rem 0}}.analysts-section h4{{color:var(--gray-700);margin-bottom:1rem;font-size:.95rem}}
.analyst-contrib{{border:1px solid var(--gray-200);border-radius:.5rem;margin-bottom:.75rem;overflow:hidden}}
.analyst-contrib.first{{border-color:var(--primary);border-width:2px}}
.contrib-header{{background:var(--gray-50);padding:.75rem 1rem;display:flex;align-items:center;gap:.75rem;flex-wrap:wrap;border-bottom:1px solid var(--gray-200)}}
.a-name{{font-weight:600;color:var(--gray-800)}}.a-id{{font-family:monospace;background:var(--gray-200);padding:.1rem .3rem;border-radius:.25rem;font-size:.75rem;color:var(--gray-600)}}
.sev-small{{color:#fff;padding:.1rem .4rem;border-radius:.5rem;font-size:.65rem;font-weight:600}}
.conf-badge{{background:var(--gray-200);padding:.1rem .4rem;border-radius:.25rem;font-size:.7rem;color:var(--gray-600)}}
.a-scores{{font-size:.75rem;color:var(--gray-500);margin-left:auto}}
.contrib-body{{padding:1rem}}.c-sec{{margin-bottom:1rem}}.c-sec:last-child{{margin-bottom:0}}
.c-sec h5{{font-size:.8rem;color:var(--gray-600);margin-bottom:.4rem;font-weight:600}}.c-sec p{{font-size:.85rem;color:var(--gray-700);line-height:1.6}}
.ev-list{{list-style:none;font-size:.8rem;margin:0;padding:0}}.ev-list li{{background:var(--gray-100);padding:.4rem .6rem;margin-bottom:.3rem;border-radius:.25rem;border-left:3px solid var(--warning)}}
.ev-list code{{word-break:break-word;font-size:.8rem}}

/* Dismissed */
.dismissed-item{{padding:.75rem 1rem;background:var(--gray-50);border-radius:.5rem;margin-bottom:.5rem;display:flex;flex-wrap:wrap;gap:.5rem;align-items:center}}
.d-id{{font-family:monospace;background:var(--gray-200);padding:.1rem .4rem;border-radius:.25rem;font-size:.8rem}}
.d-type,.d-val{{color:var(--gray-500);font-size:.8rem}}.d-title{{font-weight:500;flex:1}}.d-reason{{color:var(--gray-600);font-size:.85rem;width:100%}}

/* Other */
.concerns-list{{list-style:none}}.concerns-list li{{padding:.75rem 1rem;background:var(--gray-50);border-left:4px solid var(--primary);margin-bottom:.5rem;border-radius:0 .5rem .5rem 0}}
.assessment{{background:var(--gray-50);padding:1.5rem;border-radius:.75rem;border-left:4px solid var(--primary);margin-top:1rem}}
.conflict-item{{padding:1rem;background:var(--gray-50);border-radius:.5rem;margin-bottom:.5rem}}
.empty{{color:var(--gray-600);font-style:italic;text-align:center;padding:1rem}}
.analysts-grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:1rem}}
.analyst-card{{background:var(--gray-50);padding:1rem;border-radius:.5rem;text-align:center}}
.footer{{text-align:center;padding:2rem;color:var(--gray-600);font-size:.85rem}}

/* Source Pages */
.source-pages-viewer{{margin:1.5rem 0;border:1px solid var(--gray-200);border-radius:.75rem;overflow:hidden}}
.source-pages-viewer h4{{background:var(--gray-100);padding:.75rem 1rem;margin:0;font-size:.9rem;color:var(--gray-700)}}
.page-tabs{{display:flex;gap:0;background:var(--gray-100);border-bottom:1px solid var(--gray-200);padding:0 .5rem;overflow-x:auto}}
.page-tab{{background:none;border:none;padding:.75rem 1rem;cursor:pointer;font-size:.85rem;color:var(--gray-600);border-bottom:2px solid transparent;white-space:nowrap}}
.page-tab:hover{{color:var(--primary)}}.page-tab.active{{color:var(--primary);border-bottom-color:var(--primary);font-weight:600}}
.page-contents{{position:relative}}.page-content{{display:none;padding:1rem}}.page-content.active{{display:block}}
.page-header{{display:flex;justify-content:space-between;align-items:center;margin-bottom:.75rem;padding-bottom:.5rem;border-bottom:1px solid var(--gray-200)}}
.page-number{{font-weight:600;color:var(--gray-700)}}.highlight-legend{{font-size:.75rem;color:var(--gray-600)}}
.page-text{{font-size:.85rem;line-height:1.7;max-height:500px;overflow-y:auto;background:var(--gray-50);padding:1.25rem;border-radius:.5rem}}
.evidence-highlight{{background:var(--highlight);padding:.1rem .3rem;border-radius:.2rem;font-weight:500}}
.page-text .md-table{{width:100%;border-collapse:collapse;margin:1rem 0;font-size:.8rem}}
.page-text .md-table th,.page-text .md-table td{{border:1px solid var(--gray-200);padding:.5rem .75rem;text-align:left}}
.page-text .md-table th{{background:var(--gray-100);font-weight:600}}
.page-text code{{background:var(--gray-200);padding:.1rem .4rem;border-radius:.25rem;font-family:monospace;font-size:.85em}}
@media(max-width:768px){{.container{{padding:1rem}}.header{{padding:1.5rem}}.header h1{{font-size:1.5rem}}.page-text{{max-height:300px}}.type-name{{width:120px}}}}
</style>
</head>
<body>
<div class="container">
<div class="header">
<h1>🏛️ CSRD Council Report <small style="font-size:.5em;opacity:.8">v2.0</small></h1>
<p>Multi-Model Analysis with Peer Review</p>
<div class="meta">
<span>📄 {total_pages} pages</span>
<span>👥 {num_analysts} analysts</span>
<span>📝 {num_reviewers} reviewers</span>
<span>📅 {formatted_date}</span>
{pre_filtered_badge}
{verify_badge}
</div>
</div>

{greenwashing_alert_html}

<div class="summary-grid">
<div class="summary-card"><div class="number">{summary.get('total_confirmed_issues', 0)}</div><div class="label">Total Issues</div></div>
<div class="summary-card critical"><div class="number">{summary.get('critical_issues', 0)}</div><div class="label">Critical</div></div>
<div class="summary-card high"><div class="number">{summary.get('high_issues', 0)}</div><div class="label">High</div></div>
<div class="summary-card medium"><div class="number">{summary.get('medium_issues', 0)}</div><div class="label">Medium</div></div>
<div class="summary-card low"><div class="number">{summary.get('low_issues', 0)}</div><div class="label">Low</div></div>
<div class="summary-card verify"><div class="number">{total_needs_verification}</div><div class="label">To Verify</div></div>
</div>

<div class="section">
<h2>📋 Executive Summary</h2>
{type_breakdown_html}
<h3 style="margin:1rem 0 .75rem;color:var(--gray-700)">Key Concerns</h3>
<ul class="concerns-list">{concerns_html}</ul>
<div class="assessment"><strong>Overall Assessment:</strong><br><br>{html.escape(summary.get('overall_assessment', 'N/A'))}</div>
</div>

{verification_html}

<div class="section">
<h2>✅ Confirmed Issues ({len(confirmed_issues)})</h2>
{issues_html or '<p class="empty">No confirmed issues.</p>'}
</div>

<div class="section">
<h2>❌ Dismissed Issues ({len(dismissed_issues)})</h2>
{dismissed_html}
</div>

<div class="section">
<h2>⚖️ Conflicts Resolved ({len(conflicts)})</h2>
{conflicts_html}
</div>

{council_section}

<div class="footer">
<p>Generated by CSRD LLM Council Analyzer v2.0</p>
<p>All intermediate outputs available in JSON format</p>
</div>
</div>

<script>
function showPage(tabId, btn) {{
    const card = btn.closest('.issue-card') || btn.closest('.source-pages-viewer').parentElement;
    card.querySelectorAll('.page-content').forEach(c => c.classList.remove('active'));
    card.querySelectorAll('.page-tab').forEach(t => t.classList.remove('active'));
    document.getElementById(tabId).classList.add('active');
    btn.classList.add('active');
}}
</script>
</body>
</html>'''