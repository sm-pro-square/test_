"""
Phase 3: Judgment (Chunk-by-Chunk) v2.0
=======================================

Final judgment phase where a judge LLM consolidates findings chunk by chunk.
Updated to support:
- New "needs_verification" category for uncertain issues
- GREENWASHING detection
- Enhanced cross-section risk handling
- Better statistics and reporting

Architecture:
- For each chunk, the judge receives:
  - The actual page content (markdown)
  - All issues from that chunk (that passed validity filter)
  - Review scores for each issue
- The judge validates issues against source text and consolidates duplicates
- Finally, we aggregate all chunk results

Usage:
    python -m csrd_council.phases.phase3_judgment \\
        --phase1-dir ./outputs \\
        --phase2-dir ./outputs \\
        --config council_config.json \\
        --document report.json \\
        --output-dir ./outputs
"""

import os
import sys
import json
import argparse
from typing import List, Dict, Optional, Tuple
from collections import defaultdict

if __name__ == "__main__":
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from csrd_council_2.config.models import CouncilConfig, ModelConfig
from csrd_council_2.config.prompts_v5 import JUDGE_SYSTEM_PROMPT, format_judge_chunk_prompt
from csrd_council_2.models.llm_client import LLMClient
from csrd_council_2.utils.helpers import (
    load_json, save_json, parse_llm_response, get_timestamp,
    find_phase1_files, find_phase2_files, load_document, chunk_by_pages
)
from csrd_council_2.utils.html_generator import generate_html_report


# =============================================================================
# CONFIGURATION v2.0
# =============================================================================

# Validity thresholds
MIN_VALIDITY_CONFIRM = 0.7      # Minimum to confirm an issue
MIN_VALIDITY_VERIFY = 0.5       # Minimum to put in "needs_verification"
# Below MIN_VALIDITY_VERIFY = dismissed

# Types with high false positive risk
HIGH_FP_RISK_TYPES = [
    "MISSING_INFORMATION",
    "AMBIGUOUS_STATEMENT",
]

# Types with high priority (regulatory risk)
HIGH_PRIORITY_TYPES = [
    "GREENWASHING",
    "REGULATORY_GAP",
    "NUMERIC_INCONSISTENCY",
    "LOGICAL_CONTRADICTION",
]


# =============================================================================
# DATA LOADING
# =============================================================================

def load_phase1_data(phase1_dir: str) -> Dict:
    """Load all Phase 1 analysis files."""
    files = find_phase1_files(phase1_dir)
    all_issues = []
    analyses = []
    
    for filepath in files:
        data = load_json(filepath)
        analyst = data.get("analyst_id", data.get("analyst", "Unknown"))
        
        analyses.append({
            "analyst": analyst,
            "file": filepath,
            "total_issues": data.get("total_issues", len(data.get("issues", [])))
        })
        
        for issue in data.get("issues", []):
            issue["_source_analyst"] = analyst
            issue["_source_file"] = filepath
            all_issues.append(issue)
    
    return {"issues": all_issues, "analyses": analyses, "files": files}


def load_phase2_data(phase2_dir: str) -> Dict:
    """Load all Phase 2 review files."""
    files = find_phase2_files(phase2_dir)
    all_reviews = []
    aggregate_stats = {}
    
    for filepath in files:
        data = load_json(filepath)
        
        # Capture aggregate stats if present (v2 format)
        if "aggregate_stats" in data:
            aggregate_stats = data["aggregate_stats"]
        
        for review in data.get("reviews", []):
            review["_source_file"] = filepath
            all_reviews.append(review)
    
    return {"reviews": all_reviews, "files": files, "aggregate_stats": aggregate_stats}


# =============================================================================
# ISSUE PROCESSING
# =============================================================================

def organize_issues_by_chunk(issues: List[Dict]) -> Dict[int, List[Dict]]:
    """Organize issues by their source_chunk."""
    by_chunk = defaultdict(list)
    for issue in issues:
        source_chunk = issue.get("source_chunk", 0)
        by_chunk[source_chunk].append(issue)

    return dict(by_chunk)


def aggregate_reviews_for_issue(issue_id: str, reviews: List[Dict]) -> Dict:
    """Aggregate review scores for a single issue."""
    issue_reviews = [r for r in reviews if r.get("issue_id") == issue_id]
    
    if not issue_reviews:
        return {
            "avg_validity": 0.0, 
            "avg_evidence": 0.0, 
            "num_reviews": 0, 
            "reviews": [],
            "cross_section_risk": "UNKNOWN",
            "high_fp_risk": False
        }
    
    valid_evals = [r.get("evaluation", {}) for r in issue_reviews 
                   if isinstance(r.get("evaluation"), dict) and "validity_score" in r.get("evaluation", {})]
    
    if not valid_evals:
        return {
            "avg_validity": 0.0, 
            "avg_evidence": 0.0, 
            "num_reviews": 0, 
            "reviews": issue_reviews,
            "cross_section_risk": "UNKNOWN",
            "high_fp_risk": False
        }
    
    avg_validity = sum(e.get("validity_score", 0) for e in valid_evals) / len(valid_evals)
    avg_evidence = sum(e.get("evidence_score", 0) for e in valid_evals) / len(valid_evals)
    
    # Get cross-section risk (take highest risk level)
    risk_levels = {"HIGH": 3, "MEDIUM": 2, "LOW": 1, "NONE": 0, "UNKNOWN": -1}
    cross_risks = [e.get("cross_section_risk", "UNKNOWN") for e in valid_evals]
    max_risk = max(cross_risks, key=lambda x: risk_levels.get(x, -1))
    
    # Check if any review flagged high FP risk
    high_fp_risk = any(r.get("high_fp_risk", False) for r in issue_reviews)
    
    return {
        "avg_validity": avg_validity,
        "avg_evidence": avg_evidence,
        "num_reviews": len(valid_evals),
        "reviews": issue_reviews,
        "cross_section_risk": max_risk,
        "high_fp_risk": high_fp_risk
    }


def enrich_issues_with_reviews(issues: List[Dict], reviews: List[Dict]) -> List[Dict]:
    """Add review data to each issue."""
    enriched = []
    for issue in issues:
        issue_id = issue.get("issue_id", "")
        agg = aggregate_reviews_for_issue(issue_id, reviews)
        
        # Determine if this issue type is high FP risk
        issue_type = issue.get("type", "")
        is_high_fp_risk = issue_type in HIGH_FP_RISK_TYPES or agg.get("high_fp_risk", False)
        is_high_priority = issue_type in HIGH_PRIORITY_TYPES
        
        enriched_issue = {
            **issue, 
            "aggregate_scores": agg, 
            "reviews": agg.get("reviews", []),
            "is_high_fp_risk": is_high_fp_risk,
            "is_high_priority": is_high_priority
        }
        enriched.append(enriched_issue)
    
    return enriched


def filter_issues_by_validity(
    issues: List[Dict],
    min_validity_confirm: float = MIN_VALIDITY_CONFIRM,
    min_validity_verify: float = MIN_VALIDITY_VERIFY
) -> Tuple[List[Dict], List[Dict], List[Dict]]:
    """
    Three-way filter for issues by validity score.
    
    Returns:
        Tuple of (confirmed, needs_verification, dismissed)
    """
    confirmed = []
    needs_verification = []
    dismissed = []
    
    for issue in issues:
        agg = issue.get("aggregate_scores", {})
        validity = agg.get("avg_validity", 0)
        cross_section_risk = agg.get("cross_section_risk", "UNKNOWN")
        is_high_fp_risk = issue.get("is_high_fp_risk", False)
        issue_type = issue.get("type", "")
        
        # Decision logic
        if validity >= min_validity_confirm:
            # High validity - but check cross-section risk for HIGH_FP_RISK types
            if is_high_fp_risk and cross_section_risk == "HIGH":
                # Demote to needs_verification
                issue["_filter_reason"] = f"Validity {validity:.2f} but cross-section risk HIGH for {issue_type}"
                needs_verification.append(issue)
            else:
                confirmed.append(issue)
        
        elif validity >= min_validity_verify:
            # Medium validity - needs verification
            issue["_filter_reason"] = f"Validity score {validity:.2f} in verification range [{min_validity_verify}, {min_validity_confirm})"
            needs_verification.append(issue)
        
        else:
            # Low validity - dismissed
            issue["_filter_reason"] = f"Validity score {validity:.2f} < {min_validity_verify}"
            dismissed.append(issue)
    
    return confirmed, needs_verification, dismissed


# =============================================================================
# CHUNK-BY-CHUNK JUDGMENT
# =============================================================================

def run_judge_on_chunk(
    judge: ModelConfig,
    chunk_content: str,
    chunk_issues: List[Dict],
    source_chunk: int,
    page_start: int,
    page_end: int,
    llm_client: LLMClient,
    verbose: bool = True
) -> Dict:
    """Run judge on a single chunk with its issues and source content."""
    if not chunk_issues:
        return {"confirmed_issues": [], "dismissed_issues": [], "needs_verification": []}
    
    if verbose:
        # Count by priority
        high_priority = sum(1 for i in chunk_issues if i.get("is_high_priority"))
        high_fp_risk = sum(1 for i in chunk_issues if i.get("is_high_fp_risk"))
        print(f"   📄 Chunk {source_chunk} (pages {page_start}-{page_end}): {len(chunk_issues)} issues")
        if high_priority > 0:
            print(f"      🔴 High priority: {high_priority}")
        if high_fp_risk > 0:
            print(f"      ⚠️  High FP risk: {high_fp_risk}")
    
    # Format issues for the prompt
    issues_for_prompt = []
    for issue in chunk_issues:
        agg = issue.get("aggregate_scores", {})
        issues_for_prompt.append({
            "issue_id": issue.get("issue_id"),
            "analyst": issue.get("_source_analyst"),
            "type": issue.get("type"),
            "severity": issue.get("severity"),
            "title": issue.get("title"),
            "description": issue.get("description"),
            "page_references": issue.get("page_references", []),
            "evidence": issue.get("evidence", []),
            "recommendation": issue.get("recommendation"),
            "validity_score": round(agg.get("avg_validity", 0), 2),
            "evidence_score": round(agg.get("avg_evidence", 0), 2),
            "cross_section_risk": agg.get("cross_section_risk", "UNKNOWN"),
            "confidence": issue.get("confidence", "MEDIUM")
        })
    
    # Format prompt
    user_prompt = format_judge_chunk_prompt(
        chunk_content=chunk_content,
        chunk_id=source_chunk,
        page_start=page_start,
        page_end=page_end,
        issues=json.dumps(issues_for_prompt, indent=2, ensure_ascii=False),
        num_issues=len(chunk_issues)
    )
    
    # Call LLM
    response = llm_client.generate(judge, user_prompt, JUDGE_SYSTEM_PROMPT)
    
    if not response.success:
        if verbose:
            print(f"      ❌ Error: {response.error}")
        return build_fallback_result(chunk_issues, source_chunk, page_start, page_end, "LLM Error")
    
    # Parse response
    parsed = parse_llm_response(response.answer)
    
    if parsed.get("parse_error"):
        if verbose:
            print(f"      ⚠️  Parse error, keeping all issues")
        return build_fallback_result(chunk_issues, source_chunk, page_start, page_end, "Parse Error")
    
    # Process judge output
    return process_judge_output(parsed, chunk_issues, source_chunk, page_start, page_end, verbose)


def process_judge_output(
    parsed: Dict,
    chunk_issues: List[Dict],
    source_chunk: int,
    page_start: int,
    page_end: int,
    verbose: bool
) -> Dict:
    """Process judge output and match back to original issues."""
    confirmed = []
    needs_verification = []
    dismissed_ids = set()
    
    # Track dismissed issues with reasons
    dismissed_info = {}
    for d in parsed.get("dismissed_issues", []):
        issue_id = d.get("issue_id", "")
        dismissed_ids.add(issue_id)
        dismissed_info[issue_id] = d.get("reason", d.get("detailed_explanation", "Dismissed by judge"))
    
    original_map = {i.get("issue_id"): i for i in chunk_issues}
    
    # Process confirmed issues from judge
    for conf in parsed.get("confirmed_issues", []):
        grouped_ids = conf.get("grouped_issue_ids", [])
        if not grouped_ids:
            continue
        
        group_originals = [original_map[gid] for gid in grouped_ids if gid in original_map]
        if not group_originals:
            continue
        
        consolidated = build_consolidated_issue(conf, group_originals, source_chunk, page_start, page_end, len(confirmed))
        confirmed.append(consolidated)
    
    # Process needs_verification if judge returned them
    for verify in parsed.get("needs_verification", []):
        issue_id = verify.get("issue_id", "")
        if issue_id in original_map:
            orig = original_map[issue_id]
            needs_verification.append({
                **orig,
                "verification_reason": verify.get("reason", "Requires cross-section verification"),
                "what_to_check": verify.get("what_to_check", ""),
                "sections_to_review": verify.get("sections_to_review", [])
            })
    
    # Keep issues not mentioned by judge (neither confirmed, dismissed, nor needs_verification)
    mentioned_ids = set()
    for conf in parsed.get("confirmed_issues", []):
        mentioned_ids.update(conf.get("grouped_issue_ids", []))
    mentioned_ids.update(dismissed_ids)
    for verify in parsed.get("needs_verification", []):
        mentioned_ids.add(verify.get("issue_id", ""))
    
    for issue_id, orig in original_map.items():
        if issue_id not in mentioned_ids:
            # Issue not processed by judge - keep it as confirmed
            consolidated = build_single_issue(orig, source_chunk, page_start, page_end, len(confirmed))
            consolidated["validation_notes"] = "Not explicitly processed by judge - kept by default"
            confirmed.append(consolidated)
    
    # Build dismissed list
    dismissed = []
    for issue_id, reason in dismissed_info.items():
        if issue_id in original_map:
            dismissed.append({
                **original_map[issue_id],
                "dismissal_reason": reason
            })
    
    if verbose:
        print(f"      ✅ Confirmed: {len(confirmed)}, Needs verification: {len(needs_verification)}, Dismissed: {len(dismissed)}")
    
    return {
        "confirmed_issues": confirmed, 
        "dismissed_issues": dismissed,
        "needs_verification": needs_verification
    }


def build_consolidated_issue(conf: Dict, originals: List[Dict], source_chunk: int, page_start: int, page_end: int, index: int) -> Dict:
    """Build a consolidated issue from multiple analyst reports."""
    all_pages = set()
    all_evidence = []
    contributions = []
    
    for orig in originals:
        contribution = {
            "analyst": orig.get("_source_analyst", "Unknown"),
            "issue_id": orig.get("issue_id"),
            "title": orig.get("title"),
            "description": orig.get("description"),
            "severity": orig.get("severity"),
            "type": orig.get("type"),
            "page_references": orig.get("page_references", []),
            "evidence": orig.get("evidence", []),
            "recommendation": orig.get("recommendation"),
            "aggregate_scores": orig.get("aggregate_scores", {}),
            "confidence": orig.get("confidence", "MEDIUM")
        }
        contributions.append(contribution)
        
        for p in orig.get("page_references", []):
            all_pages.add(p)
        for e in orig.get("evidence", []):
            if e not in all_evidence:
                all_evidence.append(e)
    
    sorted_pages = sorted(list(all_pages), key=lambda x: int(''.join(filter(str.isdigit, str(x))) or 0))
    
    avg_validity = sum(c["aggregate_scores"].get("avg_validity", 0) for c in contributions) / len(contributions) if contributions else 0
    avg_evidence = sum(c["aggregate_scores"].get("avg_evidence", 0) for c in contributions) / len(contributions) if contributions else 0
    
    # Check if any contribution is high priority
    is_high_priority = any(c.get("type") in HIGH_PRIORITY_TYPES for c in contributions)
    
    return {
        "final_id": conf.get("final_id", f"CHUNK{source_chunk}-{index+1:03d}"),
        "grouped_issue_ids": [o.get("issue_id") for o in originals],
        "type": conf.get("type", originals[0].get("type")),
        "final_severity": conf.get("final_severity", originals[0].get("severity")),
        "title": conf.get("title", originals[0].get("title")),
        "description": conf.get("description", originals[0].get("description", "")),
        "grouping_rationale": conf.get("grouping_rationale", ""),
        "validation_notes": conf.get("validation_notes", ""),
        "evidence_verified": conf.get("evidence_verified", True),
        "source_chunk": source_chunk,
        "page_start": page_start,
        "page_end": page_end,
        "analyst_contributions": contributions,
        "all_page_references": sorted_pages,
        "all_evidence": all_evidence,
        "page_references": sorted_pages,
        "evidence": all_evidence,
        "is_high_priority": is_high_priority,
        "consensus": {
            "num_analysts": len(contributions),
            "review_scores": {"validity": avg_validity, "evidence": avg_evidence},
            "confidence": "HIGH" if len(contributions) > 1 else "MEDIUM"
        }
    }


def build_single_issue(orig: Dict, source_chunk: int, page_start: int, page_end: int, index: int) -> Dict:
    """Build a single-analyst issue."""
    agg = orig.get("aggregate_scores", {})
    issue_type = orig.get("type", "")
    
    return {
        "final_id": f"CHUNK{source_chunk}-{index+1:03d}",
        "grouped_issue_ids": [orig.get("issue_id")],
        "type": issue_type,
        "final_severity": orig.get("severity"),
        "title": orig.get("title"),
        "description": orig.get("description", ""),
        "grouping_rationale": "",
        "validation_notes": "",
        "evidence_verified": True,
        "source_chunk": source_chunk,
        "page_start": page_start,
        "page_end": page_end,
        "analyst_contributions": [{
            "analyst": orig.get("_source_analyst", "Unknown"),
            "issue_id": orig.get("issue_id"),
            "title": orig.get("title"),
            "description": orig.get("description"),
            "severity": orig.get("severity"),
            "type": issue_type,
            "page_references": orig.get("page_references", []),
            "evidence": orig.get("evidence", []),
            "recommendation": orig.get("recommendation"),
            "aggregate_scores": agg,
            "confidence": orig.get("confidence", "MEDIUM")
        }],
        "all_page_references": orig.get("page_references", []),
        "all_evidence": orig.get("evidence", []),
        "page_references": orig.get("page_references", []),
        "evidence": orig.get("evidence", []),
        "is_high_priority": issue_type in HIGH_PRIORITY_TYPES,
        "consensus": {
            "num_analysts": 1,
            "review_scores": {"validity": agg.get("avg_validity", 0), "evidence": agg.get("avg_evidence", 0)},
            "confidence": "MEDIUM"
        }
    }


def build_fallback_result(issues: List[Dict], source_chunk: int, page_start: int, page_end: int, reason: str) -> Dict:
    """Build fallback result when judge fails."""
    confirmed = []
    for idx, issue in enumerate(issues):
        consolidated = build_single_issue(issue, source_chunk, page_start, page_end, idx)
        consolidated["validation_notes"] = f"Fallback: {reason}"
        confirmed.append(consolidated)
    
    return {"confirmed_issues": confirmed, "dismissed_issues": [], "needs_verification": [], "fallback": True}


# =============================================================================
# AGGREGATION
# =============================================================================

def aggregate_chunk_results(chunk_results: List[Dict], verbose: bool = True) -> Dict:
    """Aggregate results from all chunks."""
    all_confirmed = []
    all_dismissed = []
    all_needs_verification = []
    
    for result in chunk_results:
        all_confirmed.extend(result.get("confirmed_issues", []))
        all_dismissed.extend(result.get("dismissed_issues", []))
        all_needs_verification.extend(result.get("needs_verification", []))
    
    if verbose:
        print(f"\n📊 Aggregating {len(all_confirmed)} confirmed issues from {len(chunk_results)} chunks...")
    
    # Sort by severity
    severity_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}
    all_confirmed.sort(key=lambda x: (severity_order.get(x.get("final_severity", "MEDIUM"), 2), x.get("source_chunk", 0)))
    
    # Assign final IDs
    for idx, issue in enumerate(all_confirmed, 1):
        issue["final_id"] = f"CSRD-{idx:03d}"
    
    # Count by type
    type_counts = defaultdict(int)
    for issue in all_confirmed:
        type_counts[issue.get("type", "UNKNOWN")] += 1
    
    # Count greenwashing specifically
    greenwashing_count = type_counts.get("GREENWASHING", 0)
    greenwashing_risk = "CRITICAL" if greenwashing_count >= 3 else "HIGH" if greenwashing_count >= 1 else "LOW"
    
    summary = {
        "total_confirmed_issues": len(all_confirmed),
        "critical_issues": sum(1 for i in all_confirmed if i.get("final_severity") == "CRITICAL"),
        "high_issues": sum(1 for i in all_confirmed if i.get("final_severity") == "HIGH"),
        "medium_issues": sum(1 for i in all_confirmed if i.get("final_severity") == "MEDIUM"),
        "low_issues": sum(1 for i in all_confirmed if i.get("final_severity") == "LOW"),
        "total_dismissed": len(all_dismissed),
        "total_needs_verification": len(all_needs_verification),
        "chunks_processed": len(chunk_results),
        "by_type": dict(type_counts),
        "greenwashing_count": greenwashing_count,
        "greenwashing_risk_level": greenwashing_risk,
        "high_priority_issues": sum(1 for i in all_confirmed if i.get("is_high_priority")),
        "key_concerns": [i.get("title", "") for i in all_confirmed if i.get("final_severity") in ["CRITICAL", "HIGH"]][:5],
        "overall_assessment": ""
    }
    
    if verbose:
        print(f"   ✅ Final: {summary['total_confirmed_issues']} confirmed, {summary['total_needs_verification']} needs verification, {summary['total_dismissed']} dismissed")
        print(f"      CRITICAL: {summary['critical_issues']}, HIGH: {summary['high_issues']}, MEDIUM: {summary['medium_issues']}, LOW: {summary['low_issues']}")
        if greenwashing_count > 0:
            print(f"      🚨 GREENWASHING issues: {greenwashing_count} (risk level: {greenwashing_risk})")
    
    return {
        "confirmed_issues": all_confirmed, 
        "dismissed_issues": all_dismissed, 
        "needs_verification": all_needs_verification,
        "executive_summary": summary
    }


# =============================================================================
# MAIN RUNNER
# =============================================================================

def run_phase3(
    phase1_dir: str,
    phase2_dir: str,
    config: CouncilConfig,
    output_dir: str,
    document_path: Optional[str] = None,
    num_pages: Optional[int] = None,
    min_validity_confirm: float = MIN_VALIDITY_CONFIRM,
    min_validity_verify: float = MIN_VALIDITY_VERIFY,
    pages_per_chunk: int = 30,
    mock_mode: bool = False,
    verbose: bool = True
) -> Dict[str, str]:
    """Run Phase 3 judgment with chunk-by-chunk processing."""
    if verbose:
        print("\n" + "="*70)
        print("PHASE 3: FINAL JUDGMENT (Chunk-by-Chunk) v2.0")
        print("="*70)
    
    if not document_path or not os.path.exists(document_path):
        print("❌ Document path required for chunk-by-chunk processing")
        return {}
    
    if verbose:
        print(f"\n📄 Loading document: {document_path}")
    
    pages = load_document(document_path)
    document_pages = {p['page_number']: p['content'] for p in pages}
    num_pages = len(pages)
    
    if verbose:
        print(f"   Loaded {num_pages} pages")
    
    chunks = chunk_by_pages(pages, pages_per_chunk=pages_per_chunk, overlap_pages=2)
    
    if verbose:
        print(f"   Split into {len(chunks)} chunks")
    
    if verbose:
        print(f"\n📂 Loading Phase 1 data from: {phase1_dir}")
    phase1_data = load_phase1_data(phase1_dir)
    
    if not phase1_data["issues"]:
        print("❌ No issues found in Phase 1 data")
        return {}
    
    if verbose:
        print(f"   Found {len(phase1_data['issues'])} issues from {len(phase1_data['analyses'])} analyst(s)")
        print(f"📂 Loading Phase 2 data from: {phase2_dir}")
    
    phase2_data = load_phase2_data(phase2_dir)
    
    if verbose:
        print(f"   Found {len(phase2_data['reviews'])} review(s)")
        if phase2_data.get("aggregate_stats"):
            stats = phase2_data["aggregate_stats"]
            print(f"   Phase 2 stats: {stats.get('high_validity_count', '?')} high validity, {stats.get('low_validity_count', '?')} low validity")
    
    # Enrich issues with review data
    enriched_issues = enrich_issues_with_reviews(phase1_data["issues"], phase2_data["reviews"])
    
    # Three-way filter
    confirmed_issues, verification_issues, dismissed_issues = filter_issues_by_validity(
        enriched_issues, 
        min_validity_confirm, 
        min_validity_verify
    )
    
    if verbose:
        print(f"\n🔽 Pre-filtering results:")
        print(f"   ✅ Confirmed (validity ≥ {min_validity_confirm}): {len(confirmed_issues)}")
        print(f"   🔍 Needs verification ({min_validity_verify} ≤ validity < {min_validity_confirm}): {len(verification_issues)}")
        print(f"   ❌ Dismissed (validity < {min_validity_verify}): {len(dismissed_issues)}")
        
        # Show type breakdown for high FP risk types
        high_fp_confirmed = sum(1 for i in confirmed_issues if i.get("is_high_fp_risk"))
        high_fp_verify = sum(1 for i in verification_issues if i.get("is_high_fp_risk"))
        if high_fp_confirmed + high_fp_verify > 0:
            print(f"   ⚠️  High FP risk types: {high_fp_confirmed} confirmed, {high_fp_verify} needs verification")
    
    # Organize confirmed issues by chunk for judgment
    issues_by_chunk = organize_issues_by_chunk(confirmed_issues)
    
    if verbose:
        print(f"   Issues distributed across {len([c for c in issues_by_chunk.values() if c])} chunks")
    
    if not config.judge:
        print("❌ No judge configured")
        return {}
    
    llm_client = LLMClient(mock_mode=mock_mode)
    
    if verbose:
        print(f"\n⚖️  Running judge ({config.judge.name}) on each chunk...")
    
    chunk_results = []
    for chunk in chunks:
        source_chunk = chunk["chunk_id"]
        chunk_issues = issues_by_chunk.get(source_chunk, [])
        
        if not chunk_issues:
            continue
        
        result = run_judge_on_chunk(
            judge=config.judge,
            chunk_content=chunk["text"],
            chunk_issues=chunk_issues,
            source_chunk=source_chunk,
            page_start=chunk["page_start"],
            page_end=chunk["page_end"],
            llm_client=llm_client,
            verbose=verbose
        )
        chunk_results.append(result)
    
    judgment = aggregate_chunk_results(chunk_results, verbose=verbose)
    
    # Add pre-filtered dismissed issues
    for issue in dismissed_issues:
        judgment["dismissed_issues"].append({
            "issue_id": issue.get("issue_id"),
            "title": issue.get("title"),
            "type": issue.get("type"),
            "analyst": issue.get("_source_analyst"),
            "dismissal_reason": issue.get("_filter_reason", "Pre-filtered due to low validity"),
            "validity_score": issue.get("aggregate_scores", {}).get("avg_validity", 0)
        })
    
    # Add verification issues that weren't processed
    for issue in verification_issues:
        # Check if not already in needs_verification from judge
        existing_ids = {v.get("issue_id") for v in judgment.get("needs_verification", [])}
        if issue.get("issue_id") not in existing_ids:
            judgment["needs_verification"].append({
                "issue_id": issue.get("issue_id"),
                "title": issue.get("title"),
                "type": issue.get("type"),
                "analyst": issue.get("_source_analyst"),
                "verification_reason": issue.get("_filter_reason", "Medium validity - requires verification"),
                "validity_score": issue.get("aggregate_scores", {}).get("avg_validity", 0),
                "cross_section_risk": issue.get("aggregate_scores", {}).get("cross_section_risk", "UNKNOWN"),
                "what_to_check": "Verify if information exists in other sections of the report",
                "page_references": issue.get("page_references", [])
            })
    
    # Update summary counts
    judgment["executive_summary"]["pre_filtered_count"] = len(dismissed_issues)
    judgment["executive_summary"]["total_needs_verification"] = len(judgment.get("needs_verification", []))
    judgment["executive_summary"]["overall_assessment"] = generate_overall_assessment(judgment)
    
    os.makedirs(output_dir, exist_ok=True)
    
    judgment["_metadata"] = {
        "timestamp": get_timestamp(),
        "version": "2.0",
        "document_path": document_path,
        "num_pages": num_pages,
        "num_chunks": len(chunks),
        "chunks_with_issues": len(chunk_results),
        "phase1_files": phase1_data["files"],
        "phase2_files": phase2_data["files"],
        "judge": config.judge.name,
        "judge_model": config.judge.model_id,
        "thresholds": {
            "min_validity_confirm": min_validity_confirm,
            "min_validity_verify": min_validity_verify
        },
        "total_issues_before_filter": len(enriched_issues),
        "issues_confirmed_for_judgment": len(confirmed_issues),
        "issues_needs_verification": len(verification_issues),
        "issues_pre_filtered": len(dismissed_issues)
    }
    
    json_path = os.path.join(output_dir, "phase3_judgment.json")
    save_json(judgment, json_path)
    if verbose:
        print(f"\n💾 Saved: {json_path}")
    
    metadata = {
        "total_pages": num_pages,
        "num_analysts": len(phase1_data["analyses"]),
        "num_reviewers": len(set(r.get("reviewer_id") for r in phase2_data["reviews"])),
        "num_chunks": len(chunks),
        "generated_at": get_timestamp(),
        "version": "2.0"
    }
    
    html = generate_html_report(judgment, metadata, phase1_data["analyses"], document_pages)
    
    html_path = os.path.join(output_dir, "final_report.html")
    with open(html_path, 'w', encoding='utf-8') as f:
        f.write(html)
    
    if verbose:
        print(f"💾 Saved: {html_path}")
        print(f"\n✅ Phase 3 complete")
        
        # Final summary
        summary = judgment.get("executive_summary", {})
        print(f"\n" + "="*50)
        print(f"📋 FINAL REPORT SUMMARY")
        print(f"="*50)
        print(f"   Confirmed issues: {summary.get('total_confirmed_issues', 0)}")
        print(f"   Needs verification: {summary.get('total_needs_verification', 0)}")
        print(f"   Dismissed: {summary.get('total_dismissed', 0) + summary.get('pre_filtered_count', 0)}")
        if summary.get('greenwashing_count', 0) > 0:
            print(f"   🚨 Greenwashing risk: {summary.get('greenwashing_risk_level', 'UNKNOWN')}")
    
    return {"json": json_path, "html": html_path}


def generate_overall_assessment(judgment: Dict) -> str:
    """Generate overall assessment text."""
    summary = judgment.get("executive_summary", {})
    total = summary.get("total_confirmed_issues", 0)
    critical = summary.get("critical_issues", 0)
    high = summary.get("high_issues", 0)
    needs_verification = summary.get("total_needs_verification", 0)
    greenwashing = summary.get("greenwashing_count", 0)
    
    parts = []
    
    if greenwashing > 0:
        parts.append(f"⚠️ ATTENTION: {greenwashing} problème(s) de GREENWASHING détecté(s), nécessitant une revue prioritaire.")
    
    if critical > 0:
        parts.append(f"Le document présente {critical} problème(s) CRITIQUE(S) nécessitant une attention immédiate, ainsi que {high} problème(s) de haute priorité.")
    elif high > 3:
        parts.append(f"Le document contient {high} problèmes de haute priorité qui devraient être corrigés.")
    elif total > 10:
        parts.append(f"Le document présente {total} problèmes identifiés, principalement de priorité moyenne ou basse.")
    else:
        parts.append(f"Le document est globalement conforme avec {total} problème(s) mineur(s) identifié(s).")
    
    if needs_verification > 0:
        parts.append(f"Note: {needs_verification} issue(s) nécessitent une vérification manuelle dans d'autres sections du rapport.")
    
    return " ".join(parts)


def main():
    parser = argparse.ArgumentParser(description="CSRD Council - Phase 3: Judgment (Chunk-by-Chunk) v2.0")
    
    parser.add_argument("--phase1-dir", required=True, help="Directory containing Phase 1 outputs")
    parser.add_argument("--phase2-dir", required=True, help="Directory containing Phase 2 outputs")
    parser.add_argument("--config", "-c", required=True, help="Path to council config file")
    parser.add_argument("--document", "-d", required=True, help="Path to original document JSON")
    parser.add_argument("--output-dir", "-o", default="./outputs", help="Output directory")
    parser.add_argument("--min-validity-confirm", type=float, default=MIN_VALIDITY_CONFIRM, 
                       help=f"Minimum validity to confirm (default: {MIN_VALIDITY_CONFIRM})")
    parser.add_argument("--min-validity-verify", type=float, default=MIN_VALIDITY_VERIFY,
                       help=f"Minimum validity for verification (default: {MIN_VALIDITY_VERIFY})")
    parser.add_argument("--pages-per-chunk", type=int, default=20, help="Pages per chunk")
    parser.add_argument("--mock", action="store_true", help="Use mock LLM")
    parser.add_argument("--quiet", "-q", action="store_true", help="Suppress output")
    
    args = parser.parse_args()
    config = CouncilConfig.from_file(args.config)
    
    outputs = run_phase3(
        phase1_dir=args.phase1_dir,
        phase2_dir=args.phase2_dir,
        config=config,
        output_dir=args.output_dir,
        document_path=args.document,
        min_validity_confirm=args.min_validity_confirm,
        min_validity_verify=args.min_validity_verify,
        pages_per_chunk=args.pages_per_chunk,
        mock_mode=args.mock,
        verbose=not args.quiet
    )
    
    if outputs:
        print(f"\n📄 JSON: {outputs['json']}")
        print(f"🌐 HTML: {outputs['html']}")


if __name__ == "__main__":
    main()